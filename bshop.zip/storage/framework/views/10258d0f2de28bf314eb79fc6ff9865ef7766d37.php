<?php $__env->startSection('title' , 'Admin Panel Ad Details'); ?>

<?php $__env->startSection('content'); ?>
        <div id="tableSimple" class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.notification_details')); ?></h4>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div class="table-responsive"> 
                <table class="table table-bordered mb-4">
                    <tbody>
                            <?php if($data['notification']['image']): ?>
                                <tr>
                                    <td class="label-table" > <?php echo e(__('messages.image')); ?> </td>
                                    <td>
                                        <img src="https://res.cloudinary.com/dz3o88rdi/image/upload/w_100,q_100/v1581928924/<?php echo e($data['notification']['image']); ?>" />
                                    </td>
                                </tr>
                            <?php endif; ?>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.notification_title')); ?></td>
                                <td>
                                    <?php echo e($data['notification']['title']); ?>

                                </td>
                            </tr>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.notification_body')); ?> </td>
                                <td>
                                    <?php echo e($data['notification']['body']); ?>

                                </td>
                            </tr>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.date')); ?> </td>
                                <td>
                                    <?php echo e($data['notification']['created_at']); ?>

                                </td>
                            </tr>

                    </tbody>
                </table>

                <a href="/admin-panel/notifications/resend/<?php echo e($data['notification']['id']); ?>" class="btn btn-primary mb-2"><?php echo e(__('messages.resend_this_notification')); ?></a>
                     <?php if(session('status')): ?>
                        <div class="alert alert-success mb-4" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">x</button>
                            <strong>Success</strong> <?php echo e(session('status')); ?> </button>
                        </div> 
                    <?php endif; ?>    

            </div>
        </div>
    </div>  
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/ecommerce.u-smart.co/resources/views/admin/notification_details.blade.php ENDPATH**/ ?>
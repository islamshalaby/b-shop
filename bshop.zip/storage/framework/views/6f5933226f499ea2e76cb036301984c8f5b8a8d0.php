<?php $__env->startSection('title' , __('messages.add_new_option')); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
                <div class="row">
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                        <h4><?php echo e(__('messages.add_new_option')); ?></h4>
                 </div>
        </div>
        <form action="" method="post" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
                      
            <div class="form-group mb-4">
                <label for="title_en"><?php echo e(__('messages.title_en')); ?></label>
                <input required type="text" name="title_en" class="form-control" id="title_en" placeholder="<?php echo e(__('messages.title_en')); ?>" value="" >
            </div>
            <div class="form-group mb-4">
                <label for="title_ar"><?php echo e(__('messages.title_ar')); ?></label>
                <input required type="text" name="title_ar" class="form-control" id="title_ar" placeholder="<?php echo e(__('messages.title_ar')); ?>" value="" >
            </div>
            <div class="form-group">
                <label for="category"><?php echo e(__('messages.category')); ?></label>
                <select id="category" name="category_id" class="form-control">
                    <option selected><?php echo e(__('messages.select')); ?></option>
                    <?php $__currentLoopData = $data['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e(App::isLocale('en') ? $category->title_en : $category->title_ar); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <input type="submit" value="<?php echo e(__('messages.submit')); ?>" class="btn btn-primary">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/ecommerce.u-smart.co/resources/views/admin/option_form.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title' , __('messages.offer_edit')); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        var language = "<?php echo e(Config::get('app.locale')); ?>"
        $("#type").on("change", function() {
            $(".link-input").hide()
            $(".select-input").hide()


            $("#type_elements").html('')
            var elementType = $(this).val()
            if(elementType != 3){
            $("#type_elements").parent(".form-group").show()
            $(".link-input input").attr("disabled", "disabled");
            $(".select-input select").removeAttr('disabled');
            $.ajax({
                url : "/admin-panel/offers/fetch/" + elementType,
                type : 'GET',
                success : function (data) {
                    if (elementType == 1) {
                        $("#type_elements").siblings("label").text('<?php echo e(__("messages.product")); ?>')
                    }else if (elementType == 2){
                        $("#type_elements").siblings("label").text('<?php echo e(__("messages.category")); ?>')
                    }
                    data.forEach(function(element) {
                        var elementName = element.title_en
                        if (language == 'ar') {
                            elementName = element.title_ar
                        }
                        $("#type_elements").append(`
                            <option value="${element.id}">${elementName}</option>
                        `)
                    })
                    
                }
            })
            }else{
                $(".link-input input").removeAttr("disabled");
            $(".select-input select").attr("disabled", "disabled");
                $(".link-input").show()
            }
            
        })
        
        $(".link-input").hide()
        $(".select-input").hide()
        $(".link-input input").attr("disabled", "disabled");
            $(".select-input select").attr("disabled", "disabled");
        var elementType = $("#type").val()
        if(elementType != 3){
            $("#type_elements").parent(".form-group").show()
            $(".link-input input").attr("disabled", "disabled");
            $(".select-input select").removeAttr('disabled');
            // $target = <?php echo e($data['offer']['target_id']); ?>

            // $target = ${$data['offer']['target_id']};
            // console.log($target);

            $.ajax({
                url : "/admin-panel/offers/fetch/" + elementType,
                type : 'GET',
                success : function (data) {
                    if (elementType == 1) {
                        $("#type_elements").siblings("label").text('<?php echo e(__("messages.product")); ?>')
                    }else  if(elementType == 2){
                        $("#type_elements").siblings("label").text('<?php echo e(__("messages.category")); ?>')
                    }

                    data.forEach(function(element) {
                        itemId = "<?php echo e($data['offer']['target_id']); ?>",
                            selected = ""
                        if (itemId == element.id) {
                            selected = "selected"
                        }
                     
                        var elementName = element.title_en
                        if (language == 'ar') {
                            elementName = element.title_ar
                        }
                        $("#type_elements").append(`
                            <option ${selected}  value="${element.id}">${elementName}</option>
                        `)
                    })
                    
                }
            })
        }else{
            $(".link-input input").removeAttr("disabled");
            $(".select-input select").attr("disabled", "disabled");
            $(".link-input").show()
        }
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
                <div class="row">
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                        <h4><?php echo e(__('messages.offer_edit')); ?></h4>
                 </div>
        </div>
        <form action="" method="post" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <div class="form-group mb-4">
                <label for=""><?php echo e(__('messages.current_image')); ?></label><br>
                <img src="https://res.cloudinary.com/dz3o88rdi/image/upload/w_100,q_100/v1581928924/<?php echo e($data['offer']['image']); ?>"  />
            </div>
            <div class="custom-file-container" data-upload-id="myFirstImage">
                <label><?php echo e(__('messages.upload')); ?> (<?php echo e(__('messages.single_image')); ?>) <a href="javascript:void(0)" class="custom-file-container__image-clear" title="Clear Image">x</a></label>
                <label class="custom-file-container__custom-file" >
                    <input type="file" name="image" class="custom-file-container__custom-file__custom-file-input" accept="image/*">
                    <input type="hidden" name="MAX_FILE_SIZE" value="10485760" />
                    <span class="custom-file-container__custom-file__custom-file-control"></span>
                </label>
                <div class="custom-file-container__image-preview"></div>
            </div>

            <div class="form-group">
                <label for="size"><?php echo e(__('messages.offer_size')); ?></label>
                <select required id="size" name="size" class="form-control">
                    <option disabled selected><?php echo e(__('messages.select')); ?></option>
                    <option <?php echo e($data['offer']['size'] == 1 ? 'selected' : ''); ?> value="1"><?php echo e(__('messages.larg_size')); ?></option>
                    <option <?php echo e($data['offer']['size'] == 2 ? 'selected' : ''); ?> value="2"><?php echo e(__('messages.midium_size')); ?></option>
                    <option <?php echo e($data['offer']['size'] == 3 ? 'selected' : ''); ?> value="3"><?php echo e(__('messages.small_size')); ?></option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="type"><?php echo e(__('messages.offer_type')); ?></label>
                <select required id="type" name="type" class="form-control">
                    <option disabled selected><?php echo e(__('messages.select')); ?></option>
                    <option <?php echo e($data['offer']['type'] == 1 ? 'selected' : ''); ?> value="1"><?php echo e(__('messages.product')); ?></option>
                    <option <?php echo e($data['offer']['type'] == 2 ? 'selected' : ''); ?> value="2"><?php echo e(__('messages.category')); ?></option>
                    <option <?php echo e($data['offer']['type'] == 3 ? 'selected' : ''); ?> value="3"><?php echo e(__('messages.link')); ?></option>
                </select>
            </div>

            <div style="display: none" class="form-group select-input">
                <label for="type_elements"><?php echo e(__('messages.offer_type')); ?></label>
                <select  id="type_elements" name="target_id" class="form-control">
                </select>
            </div>

            <div style="display: none" class="form-group link-input">
                <label for="type_elements"><?php echo e(__('messages.link')); ?></label>
                <input type="text" value="<?php echo e($data['offer']['target_id']); ?>" required  name="target_id" class="form-control" >
            </div>

            <div class="form-group mb-4">
                <label for="sort"><?php echo e(__('messages.sort')); ?></label>
                <input required type="text" name="sort" class="form-control" id="sort" placeholder="<?php echo e(__('messages.sort')); ?>" value="<?php echo e($data['offer']['sort']); ?>" >
            </div>

            <input type="submit" value="<?php echo e(__('messages.submit')); ?>" class="btn btn-primary">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/ecommerce.u-smart.co/resources/views/admin/offer_edit.blade.php ENDPATH**/ ?>
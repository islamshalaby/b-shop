<?php $__env->startSection('title' , __('messages.show_products')); ?>
<?php $__env->startPush('styles'); ?>
<style>
    .filtered-list-search form button {
        left: 4px;
        right : auto
    }
    .add-prod-container {
        padding: 20px 0;
    }
    .widget.box .widget-header,
    .add-prod-container,
    .widget.prod-search {
        background-color: #1b55e2 !important;
    }
    .filtered-list-search {
        margin-top: 50px
    }
    .add-prod-container h4,
    .widget h2{
        color: #FFF
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        var language = "<?php echo e(Config::get('app.locale')); ?>",
            select = "<?php echo e(__('messages.select')); ?>"
        $(".search-manually").on('click', function() {
            $(this).hide()
            $(".filter-selects").slideDown()
        })
        $("#category").on("change", function() {
            $("#sub_category_select").parent(".form-group").hide()
            
            var categoryId = $(this).val()
            
            $("#sub_category_select").html("")
            $.ajax({
                url : "/admin-panel/products/fetchsubcategorybycategory/" + categoryId,
                type : 'GET',
                success : function (data) {
                    $("#sub_category_select").prepend(`
                            <option selected disabled>${select}</option>
                        `)
                    data.forEach(function(element) {
                        var elementName = element.title_en
                        if (language == 'ar') {
                            elementName = element.title_ar
                        }
                        
                        $("#sub_category_select").parent('.form-group').show()
                        $("#sub_category_select").append(`
                            <option value="${element.id}">${elementName}</option>
                        `)
                    })
                }
            })
        })

        $("#sub_category_select").on("change", function() {
            $("#manual_search").submit()
        })
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div id="badgeCustom" class="col-lg-12 mx-auto layout-spacing">
    <div class="statbox widget prod-search box box-shadow">
    <div id="tableSimple" class="col-lg-12 col-12 layout-spacing">
        <h2 style="margin-bottom: 20px" class="text-center"><?php echo e(__('messages.what_do_sell')); ?></h2>
        <div class="col-lg-8 col-md-8 col-sm-9 filtered-list-search mx-auto">
            <form class="form-inline my-2 my-lg-0 justify-content-center">
                <div class="w-100">
                    <input type="text" class="w-100 form-control product-search br-30" id="input-search" name="name" placeholder="<?php echo e(__('messages.search_for_product_name')); ?>">
                    <button class="btn btn-primary" type="submit"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></button>
                </div>
            </form>
        </div>
        <h5 style="cursor: pointer; color: #FFF" class="text-center search-manually"><?php echo e(__('messages.or_search_manually')); ?></h5>
        <div style="display: none" class="widget-content widget-content-area filter-selects">
            
            <form id="manual_search" action="<?php echo e(route('products.getbysubcat')); ?>">
                <div class="row">
                    <div class="form-group col-md-4">
                        <label for="category"><?php echo e(__('messages.category')); ?></label>
                        <select required id="category" class="form-control">
                            <option disabled selected><?php echo e(__('messages.select')); ?></option>
                            <?php $__currentLoopData = $data['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>"><?php echo e(App::isLocale('en') ? $category->title_en : $category->title_ar); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        </select>
                    </div>
                    <div style="display: none" class="form-group col-md-4">
                        <label for="sub_category_select"><?php echo e(__('messages.sub_category')); ?></label>
                        <select required id="sub_category_select" name="sub_cat" class="form-control">
                            <option disabled selected><?php echo e(__('messages.select')); ?></option>
                        </select>
                    </div>
                </div>
            </form>
            
        </div>
        
    </div>  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/Bshop.u-smart.co/resources/views/admin/product_search.blade.php ENDPATH**/ ?>
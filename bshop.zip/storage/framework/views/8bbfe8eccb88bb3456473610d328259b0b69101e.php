<?php $__env->startSection('title' , __('messages.product_edit')); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        var language = "<?php echo e(Config::get('app.locale')); ?>",
            select = "<?php echo e(__('messages.select')); ?>",
            siblingsCont = $("#category_options_sibling").html()
            
        $("#category").on("change", function() {
            $('select#brand').html("")
            
            var categoryId = $(this).find("option:selected").val(),
                productCategoryId = "<?php echo e($data['product']['category_id']); ?>"
            if (categoryId == productCategoryId) {
                $("#category_options_sibling .form-group").show()
                $("#category_options_sibling .form-group input").prop("disabled", false)
            }else {
                $("#category_options_sibling .form-group").hide()
                $("#category_options_sibling .form-group input").prop("disabled", true)
            }
            
            
            $.ajax({
                url : "/admin-panel/sub_categories/fetchbrand/" + categoryId,
                type : 'GET',
                success : function (data) {
                    $('#brandsParent').show()
                    $('select#brand').prop("disabled", false)
                    $('#sub_category_select').parent('.form-group').hide()
                    $('select#sub_category_select').prop("disabled", true)
                    $('select#brand').prepend(
                            `<option selected disabled>${select}</option>`
                        )
                    data.forEach(function (brand) {
                        var brandName = brand.title_en
                        if (language == 'ar') {
                            brandName = brand.title_ar
                        }
                        $('select#brand').append(
                            "<option value='" + brand.id + "'>" + brandName + "</option>"
                        )
                    })
                }
            })

            $("#category_options .row").html("")
            $.ajax({
                url : "/admin-panel/products/fetchcategoryoptions/" + categoryId,
                type : 'GET',
                success : function (data) {
                    
                    $("#category_options").show()
                    
                    data.forEach(function (option) {
                        var optionName = option.title_en,
                            elms = "<?php echo e($data['prod_options']); ?>",
                            checked = ""

                        if (language == 'ar') {
                            optionName = option.title_ar
                        }
                        if (elms.includes(option.id)) {
                            checked = "checked"
                        }
                        
                        $("#category_options .row").append(`
                        <div class="col-6">
                            <label class="new-control new-checkbox new-checkbox-text checkbox-primary">
                              <input ${checked} data-label="${optionName}" value="${option.id}" type="checkbox" class="new-control-input">
                              <span class="new-control-indicator"></span><span class="new-chk-content">${optionName}</span>
                            </label>
                        </div> 
                        `)
                    })
                }
            })

            // fetch sub category by category id
            $('select#sub_category_select').html("")
            $.ajax({
                url : "/admin-panel/products/fetchsubcategorybycategory/" + categoryId,
                type : 'GET',
                success : function (data) {
                    $('#sub_category_select').parent('.form-group').show()
                    $('select#sub_category_select').prop("disabled", false)
                    $('select#sub_category_select').prepend(
                            `<option selected disabled>${select}</option>`
                        )
                    data.forEach(function (subCategory) {
                        var subCategoryName = subCategory.title_en
                        if (language == 'ar') {
                            subCategoryName = subCategory.title_ar
                        }
                        $('select#sub_category_select').append(
                            "<option value='" + subCategory.id + "'>" + subCategoryName+ "</option>"
                        )
                    })
                }
            })
        })
        $("#brand").on("change", function() {
            $('select#sub_category_select').html("")
            var brandId = $(this).find("option:selected").val();
            
            $.ajax({
                url : "/admin-panel/products/fetchsubcategories/" + brandId,
                type : 'GET',
                success : function (data) {
                    $('#sub_category_select').parent('.form-group').show()
                    $('select#sub_category_select').prop("disabled", false)
                    $('select#sub_category_select').prepend(
                            `<option selected disabled>${select}</option>`
                        )
                    data.forEach(function (subCategory) {
                        var subCategoryName = subCategory.title_en
                        if (language == 'ar') {
                            subCategoryName = subCategory.title_ar
                        }
                        $('select#sub_category_select').append(
                            "<option value='" + subCategory.id + "'>" + subCategoryName+ "</option>"
                        )
                    })
                }
            })
        })

        var categoryId = $("#category").find("option:selected").val();
            
            $.ajax({
                url : "/admin-panel/sub_categories/fetchbrand/" + categoryId,
                type : 'GET',
                success : function (data) {
                    $('#brandsParent').show()
                    $('select#brand').prop("disabled", false)
                    
                    $('select#brand').prepend(
                        `<option selected disabled>${select}</option>`
                    )
                    data.forEach(function (brand) {
                        
                        var brandName = brand.title_en
                        if (language == 'ar') {
                            brandName = brand.title_ar
                        }
                        var selected = "",
                            brandId = "<?php echo e($data['product']['brand_id']); ?>"
                        if (brandId == brand.id) {
                            selected = "selected"
                        }
                        $('select#brand').append(
                            "<option " + selected + " value='" + brand.id + "'>" + brandName + "</option>"
                        )
                    })
                }
            })

            $.ajax({
                url : "/admin-panel/products/fetchcategoryoptions/" + categoryId,
                type : 'GET',
                success : function (data) {
                    
                    $("#category_options").show()
                    
                    data.forEach(function (option) {
                        var optionName = option.title_en,
                            elms = "<?php echo e($data['prod_options']); ?>",
                            checked = ""

                        if (language == 'ar') {
                            optionName = option.title_ar
                        }
                        if (elms.includes(option.id)) {
                            checked = "checked"
                        }
                        
                        $("#category_options .row").append(`
                        <div class="col-6">
                            <label class="new-control new-checkbox new-checkbox-text checkbox-primary">
                              <input ${checked} data-label="${optionName}" value="${option.id}" type="checkbox" class="new-control-input">
                              <span class="new-control-indicator"></span><span class="new-chk-content">${optionName}</span>
                            </label>
                        </div> 
                        `)
                    })
                }
            })
            
          
            $.ajax({
                url : "/admin-panel/products/fetchsubcategorybycategory/" + categoryId,
                type : 'GET',
                success : function (data) {
                    $('#sub_category_select').parent('.form-group').show()
                    $('select#sub_category_select').prop("disabled", false)

                    $('select#sub_category_select').prepend(
                            `<option selected disabled>${select}</option>`
                        )
                    
                    data.forEach(function (subCategory) {
                        var subCategoryName = subCategory.title_en
                        if (language == 'ar') {
                            subCategoryName = subCategory.title_ar
                        }
                        var selected = "",
                            subCategoryId = "<?php echo e($data['product']['sub_category_id']); ?>"
                        if (subCategoryId == subCategory.id) {
                            selected = "selected"
                        }
                        
                        $('select#sub_category_select').append(
                            "<option " + selected + " value='" + subCategory.id + "'>" + subCategoryName+ "</option>"
                        )
                    })
                }
            })
            

            

            $("#discount").click(function() {
                if ($(this).is(':checked')) {
                    $("#offer_percentage").parent(".form-group").show()
                    $("#offer_percentage").prop('disabled', false)
                    $("#final_price").parent(".form-group").show()
                }else {
                    $("#offer_percentage").parent(".form-group").hide()
                    $("#offer_percentage").prop('disabled', true)
                    $("#final_price").parent(".form-group").hide()
                }
            })

            $("#offer_percentage").on("keyup", function () {
                var discountValue = $("#offer_percentage").val(),
                    price = $("#price_before_offer").val(),
                    discountNumber = Number(price) * (Number(discountValue) / 100),
                    total = Number(price) - discountNumber
                $("#final_price").val(total)
            })

            $("#price_before_offer").on("keyup", function () {
                var discountValue = $("#offer_percentage").val(),
                    price = $("#price_before_offer").val(),
                    discountNumber = Number(price) * (Number(discountValue) / 100),
                    total = Number(price) - discountNumber
                $("#final_price").val(total)
            })

            $("#category_options .row").on('click', 'input', function() {
                var label = $(this).data("label"),
                        labelEn = "English " + label,
                        labelAr = "Arabic " + label,
                        elementValue = $(this).val() + "element",
                        optionId = $(this).val()
                   
                   if (language == 'ar') {
                        labelEn = label + " باللغة الإنجليزية"
                        labelAr = label + " باللغة العربية"
                   }
               if($(this).is(':checked')) {
                    $("#category_options_sibling").append(`
                    <div class="form-group mb-4 ${elementValue}">
                        <label for="title_en">${labelEn}</label>
                        <input required type="text" name="value_en[]" class="form-control" id="title_en" placeholder="${labelEn}" value="" >
                    </div>
                    <div class="form-group mb-4 ${elementValue}">
                        <label for="title_en">${labelAr}</label>
                        <input required type="text" name="value_ar[]" class="form-control" id="title_en" placeholder="${labelAr}" value="" >
                    </div>
                    <input name="option[]" value="${optionId}" type="hidden" class="new-control-input ${elementValue}">
                    `)
               }else {
                   console.log("." + elementValue)
                $("." + elementValue).remove()
               }
            })

            $("#add_home").on("change", function() {
                if ($(this).is(':checked')) {
                    $("#home_section").prop("disabled", false)
                    $("#home_section").parent(".form-group").show()
                }else {
                    $("#home_section").prop("disabled", true)
                    $("#home_section").parent(".form-group").hide()
                }
            })

            var previous = "<?php echo e(__('messages.previous')); ?>",
                next = "<?php echo e(__('messages.next')); ?>",
                finish = "<?php echo e(__('messages.finish')); ?>"

                
            $(".actions ul").find('li').eq(0).children('a').text(previous)
            $(".actions ul").find('li').eq(1).children('a').text(next)
            $(".actions ul").find('li').eq(2).children('a').text(finish)

            // add class next1 to next button to control the first section
            $(".actions ul").find('li').eq(1).children('a').addClass("next1")
            
            // section one validation
            $(".actions ul").find('li').eq(1).on("mouseover", "a.next1", function() {
                var image = $('input[name="images[]"]').val(),
                    categorySelect = $("#category").val(),
                    subCategorySelect = $("#sub_category_select").val(),
                    titleEnInput = $("input[name='title_en']").val(),
                    titleArInput = $("input[name='title_ar']").val(),
                    descriptionEnText = $('textarea[name="description_en"]').val(),
                    descriptionArText = $('textarea[name="description_ar"]').val()

                if (categorySelect > 0 && subCategorySelect > 0 && titleEnInput.length > 0 && titleArInput.length > 0 && descriptionEnText.length > 0 && descriptionArText.length > 0) {
                    $(this).attr('href', '#next')
                    $(this).addClass('next2')
                    
                }else {
                    $(this).attr('href', '#')
                }
                
            })

            // show validation messages on section 1
            $(".actions ul").find('li').eq(1).on("click", "a[href='#']", function () {
                var categorySelect = $("#category").val(),
                    subCategorySelect = $("#sub_category_select").val(),
                    titleEnInput = $("input[name='title_en']").val(),
                    titleArInput = $("input[name='title_ar']").val(),
                    descriptionEnText = $('textarea[name="description_en"]').val(),
                    descriptionArText = $('textarea[name="description_ar"]').val()
                    imagesRequired = "<?php echo e(__('messages.images_required')); ?>",
                    categoryRequired = "<?php echo e(__('messages.category_required')); ?>",
                    subCategoryRequired = "<?php echo e(__('messages.sub_category_required')); ?>",
                    titleEnRequired = "<?php echo e(__('messages.title_en_required')); ?>",
                    titleArRequired = "<?php echo e(__('messages.title_ar_required')); ?>",
                    descriptionEnRequired = "<?php echo e(__('messages.description_en_required')); ?>",
                    descriptionArRequired = "<?php echo e(__('messages.description_ar_required')); ?>"

                
                
                
                if (categorySelect > 0) {
                    $(".category-required").remove()
                }else {
                    if ($(".category-required").length) {

                    }else {
                        $("#category").after(`
                        <div style="margin-top:20px" class="alert alert-outline-danger mb-4 category-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${categoryRequired}</div>
                        `)
                    }
                }

                if (subCategorySelect > 0) {
                    $(".sub-category-required").remove()
                }else {
                    if ($(".sub-category-required").length) {

                    }else {
                        $("#sub_category_select").after(`
                        <div style="margin-top:20px" class="alert alert-outline-danger mb-4 sub-category-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${subCategoryRequired}</div>
                        `)
                    }
                }

                if (titleEnInput.length == 0) {
                    if ($(".titleEn-required").length) {

                    }else {
                        $("input[name='title_en']").after(`
                        <div style="margin-top:20px" class="alert alert-outline-danger mb-4 titleEn-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${titleEnRequired}</div>
                        `)
                    }
                }else {
                    $(".titleEn-required").remove()
                }

                if (titleArInput.length == 0) {
                    if ($(".titleAr-required").length) {

                    }else {
                        $("input[name='title_ar']").after(`
                        <div style="margin-top:20px" class="alert alert-outline-danger mb-4 titleAr-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${titleArRequired}</div>
                        `)
                    }
                }else {
                    $(".titleAr-required").remove()
                }

                if (descriptionEnText.length == 0) {
                    if ($(".descEn-required").length) {

                    }else {
                        $('textarea[name="description_en"]').after(`
                        <div style="margin-top:20px" class="alert alert-outline-danger mb-4 descEn-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${descriptionEnRequired}</div>
                        `)
                    }
                }else {
                    $(".descEn-required").remove()
                }

                if (descriptionArText.length == 0) {
                    if ($(".descAr-required").length) {

                    }else {
                        $('textarea[name="description_ar"]').after(`
                        <div style="margin-top:20px" class="alert alert-outline-danger mb-4 descAr-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${descriptionArRequired}</div>
                        `)
                    }
                }else {
                    $(".descAr-required").remove()
                }
            })

            // section three validation 
            $(".actions ul").find('li').eq(2).on("mouseover", "a", function() {
                var totalQInput = $("input[name='total_quatity']").val(),
                    remainingQInput = $("input[name='remaining_quantity']").val(),
                    priceBOfferInput = $('input[name="price_before_offer"]').val(),
                    offerCheckbox = $('input[name="offer"]'),
                    offerPerc = ""

                if (offerCheckbox.is(':checked')) {
                    offerPerc = $('input[name="offer_percentage"]').val()

                    if (offerPerc > 0 && totalQInput > 0 && remainingQInput > 0 && priceBOfferInput > 0) {
                        $(this).prop('href', '#finish')
                    }else {
                        $(this).attr('href', '#')
                    }
                }else {
                    if (totalQInput > 0 && remainingQInput > 0 && totalQInput >= remainingQInput  && priceBOfferInput > 0) {
                        $(this).attr('href', '#finish')
                    }else {
                        $(this).attr('href', '#')
                    }
                }
            })

            // show validation messages on section 3
            $(".actions ul").find('li').eq(2).on("click", "a[href='#']", function() {
                var totalQInput = $("input[name='total_quatity']").val(),
                    remainingQInput = $("input[name='remaining_quantity']").val(),
                    priceBOfferInput = $('input[name="price_before_offer"]').val(),
                    offerCheckbox = $('input[name="offer"]'),
                    offerPerc = "",
                    totalQRequired = "<?php echo e(__('messages.total_quantity_required')); ?>",
                    remainingQRequired = "<?php echo e(__('messages.remaining_quantity_required')); ?>",
                    remainingQLessTotal = "<?php echo e(__('messages.remaining_q_less_total')); ?>",
                    priceRequired = "<?php echo e(__('messages.price_required')); ?>",
                    oferrVRequired = "<?php echo e(__('messages.offer_required')); ?>"

                if (offerCheckbox.is(':checked')) {
                    offerPerc = $('input[name="offer_percentage"]').val()

                    if (offerPerc <= 0) {
                        if ($(".offerV-required").length) {
    
                        }else {
                            $('input[name="offer_percentage"]').after(`
                            <div style="margin-top:20px" class="alert alert-outline-danger mb-4 offerV-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${oferrVRequired}</div>
                            `)
                        }
                    }else {
                        $(".offerV-required").remove()
                    }

                    if (totalQInput <= 0) {
                        if ($(".totalQ-required").length) {
    
                        }else {
                            $('input[name="total_quatity"]').after(`
                            <div style="margin-top:20px" class="alert alert-outline-danger mb-4 totalQ-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${totalQRequired}</div>
                            `)
                        }
                    }else {
                        $(".totalQ-required").remove()
                    }

                    if (remainingQInput <= 0) {
                        if ($(".remainingQ-required").length) {
    
                        }else {
                            $("input[name='remaining_quantity']").after(`
                            <div style="margin-top:20px" class="alert alert-outline-danger mb-4 remainingQ-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${remainingQRequired}</div>
                            `)
                        }
                    }else {
                        $(".remainingQ-required").remove()
                    }

                    if (remainingQInput > totalQInput) {
                        
                        if ($(".remainingQLess-required").length) {
    
                        }else {
                            $("input[name='remaining_quantity']").after(`
                            <div style="margin-top:20px" class="alert alert-outline-danger mb-4 remainingQLess-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${remainingQLessTotal}${totalQInput}</div>
                            `)
                        }
                        
                    }else {
                        $(".remainingQLess-required").remove()
                    }

                    if (priceBOfferInput <= 0) {
                        if ($(".priceBOffer-required").length) {
    
                        }else {
                            $('input[name="price_before_offer"]').after(`
                            <div style="margin-top:20px" class="alert alert-outline-danger mb-4 priceBOffer-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${priceRequired}</div>
                            `)
                        }
                    }else {
                        $(".priceBOffer-required").remove()
                    }

                    
                }else {

                    if (totalQInput <= 0) {
                        if ($(".totalQ-required").length) {
    
                        }else {
                            $('input[name="total_quatity"]').after(`
                            <div style="margin-top:20px" class="alert alert-outline-danger mb-4 totalQ-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${totalQRequired}</div>
                            `)
                        }
                    }else {
                        $(".totalQ-required").remove()
                    }

                    if (remainingQInput <= 0) {
                        if ($(".remainingQ-required").length) {
    
                        }else {
                            $("input[name='remaining_quantity']").after(`
                            <div style="margin-top:20px" class="alert alert-outline-danger mb-4 remainingQ-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${remainingQRequired}</div>
                            `)
                        }
                    }else {
                        $(".remainingQ-required").remove()
                    }

                    if (remainingQInput > totalQInput) {
                        if ($(".remainingQLess-required").length) {
    
                        }else {
                            $("input[name='remaining_quantity']").after(`
                            <div style="margin-top:20px" class="alert alert-outline-danger mb-4 remainingQLess-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${remainingQLessTotal}${totalQInput}</div>
                            `)
                        }
                        
                    }else {
                        $(".remainingQLess-required").remove()
                    }

                    if (priceBOfferInput <= 0) {
                        if ($(".priceBOffer-required").length) {
    
                        }else {
                            $('input[name="price_before_offer"]').after(`
                            <div style="margin-top:20px" class="alert alert-outline-danger mb-4 priceBOffer-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${priceRequired}</div>
                            `)
                        }
                    }else {
                        $(".priceBOffer-required").remove()
                    }
                }
            })

            /*
            *  show / hide message on change value
            */
            
            // image
            $('input[name="images[]"]').on("change", function() {
                var image = $('input[name="images[]"]').val(),
                    imagesRequired = "<?php echo e(__('messages.images_required')); ?>"

                if (image.length > 0) {
                    if ($(".image-required").length) {
                        $(".image-required").remove()
                    }
                }else {
                    if ($(".image-required").length) {
                        
                    }else {
                        $('input[name="images[]"]').after(`
                        <div style="margin-top:20px" class="alert alert-outline-danger mb-4 image-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${imagesRequired}</div>
                        `)
                    }
                }
            })

            // category
            $("#category").on("change", function() {
                var categorySelect = $("#category").val(),
                    categoryRequired = "<?php echo e(__('messages.category_required')); ?>"

                if (categorySelect > 0) {
                    if ($(".category-required").length) {
                        $(".category-required").remove()
                    }
                }else {
                    if ($(".category-required").length) {

                    }else {
                        $("#category").after(`
                            <div style="margin-top:20px" class="alert alert-outline-danger mb-4 category-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${categoryRequired}</div>
                            `)
                    }
                }
            })

            // sub category
            $("#sub_category_select").on("change", function() {
                var subCategorySelect = $("#sub_category_select").val(),
                    subCategoryRequired = "<?php echo e(__('messages.sub_category_required')); ?>"

                if (subCategorySelect > 0) {
                    if ($(".sub-category-required").length) {
                        $(".sub-category-required").remove()
                    } 
                }else {
                    if ($(".sub-category-required").length) {

                    }else {
                        $("#sub_category_select").after(`
                        <div style="margin-top:20px" class="alert alert-outline-danger mb-4 sub-category-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${subCategoryRequired}</div>
                        `)
                    }
                }
            })

            // title en
            $("input[name='title_en']").on("keyup", function() {
                var titleEnInput = $("input[name='title_en']").val(),
                    titleEnRequired = "<?php echo e(__('messages.title_en_required')); ?>"

                if (titleEnInput.length > 0) {
                    if ($(".titleEn-required").length) {
                        $(".titleEn-required").remove()
                    }
                }else {
                    if ($(".titleEn-required").length) {
                        
                    }else {
                        $("input[name='title_en']").after(`
                        <div style="margin-top:20px" class="alert alert-outline-danger mb-4 titleEn-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${titleEnRequired}</div>
                        `)
                    }
                }
            })

            // title ar
            $("input[name='title_ar']").on("keyup", function() {
                var titleArInput = $("input[name='title_ar']").val(),
                    titleArRequired = "<?php echo e(__('messages.title_ar_required')); ?>"

                if (titleArInput.length > 0) {
                    if ($(".titleAr-required").length) {
                        $(".titleAr-required").remove()
                    }
                }else {
                    if ($(".titleAr-required").length) {
                        
                    }else {
                        $("input[name='title_ar']").after(`
                        <div style="margin-top:20px" class="alert alert-outline-danger mb-4 titleAr-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${titleArRequired}</div>
                        `)
                    }
                }
            })

            // description en
            $('textarea[name="description_en"]').on("keyup", function() {
                var descriptionEnText = $('textarea[name="description_en"]').val(),
                    descriptionEnRequired = "<?php echo e(__('messages.description_en_required')); ?>"

                if (descriptionEnText.length > 0) {
                    if ($(".descEn-required").length) {
                        $(".descEn-required").remove()
                    }
                }else {
                    if ($(".descEn-required").length) {

                    }else {
                        $('textarea[name="description_en"]').after(`
                        <div style="margin-top:20px" class="alert alert-outline-danger mb-4 descEn-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${descriptionEnRequired}</div>
                        `)
                    }
                }
            })
            
            // description ar
            $('textarea[name="description_ar"]').on("keyup", function() {
                var descriptionArText = $('textarea[name="description_ar"]').val(),
                    descriptionArRequired = "<?php echo e(__('messages.description_ar_required')); ?>"

                if (descriptionArText.length > 0) {
                    if ($(".descAr-required").length) {
                        $(".descAr-required").remove()
                    }
                }else {
                    if ($(".descAr-required").length) {

                    }else {
                        $('textarea[name="description_ar"]').after(`
                        <div style="margin-top:20px" class="alert alert-outline-danger mb-4 descAr-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${descriptionArRequired}</div>
                        `)
                    }
                }
            })

            // total quantity
            $("input[name='total_quatity']").on("keyup", function() {
                var totalQInput = $("input[name='total_quatity']").val(),
                    totalQRequired = "<?php echo e(__('messages.total_quantity_required')); ?>"

                if (totalQInput <= 0) {
                    if ($(".totalQ-required").length) {

                    }else {
                        $('input[name="total_quatity"]').after(`
                        <div style="margin-top:20px" class="alert alert-outline-danger mb-4 totalQ-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${totalQRequired}</div>
                        `)
                    }
                }else {
                    $(".totalQ-required").remove()
                }
            })

            // remaining quantity
            $("input[name='remaining_quantity']").on("keyup", function() {
                var remainingQInput = $("input[name='remaining_quantity']").val(),
                    totalQInput = $("input[name='total_quatity']").val(),
                    remainingQRequired = "<?php echo e(__('messages.remaining_quantity_required')); ?>",
                    remainingQLessTotal = "<?php echo e(__('messages.remaining_q_less_total')); ?>"

                if (remainingQInput <= 0) {
                    if ($(".remainingQ-required").length) {

                    }else {
                        $("input[name='remaining_quantity']").after(`
                        <div style="margin-top:20px" class="alert alert-outline-danger mb-4 remainingQ-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${remainingQRequired}</div>
                        `)
                    }
                }else {
                    $(".remainingQ-required").remove()
                }

                if (remainingQInput > totalQInput) {
                    if ($(".remainingQLess-required").length) {

                    }else {
                        $("input[name='remaining_quantity']").after(`
                        <div style="margin-top:20px" class="alert alert-outline-danger mb-4 remainingQLess-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${remainingQLessTotal}${totalQInput}</div>
                        `)
                    }
                    
                }else {
                    $(".remainingQLess-required").remove()
                }
            })

            // price before offer
            $('input[name="price_before_offer"]').on("keyup", function() {
                var priceBOfferInput = $('input[name="price_before_offer"]').val(),
                    priceRequired = "<?php echo e(__('messages.price_required')); ?>"

                if (priceBOfferInput <= 0) {
                    if ($(".priceBOffer-required").length) {
    
                    }else {
                        $('input[name="price_before_offer"]').after(`
                        <div style="margin-top:20px" class="alert alert-outline-danger mb-4 priceBOffer-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${priceRequired}</div>
                        `)
                    }
                }else {
                    $(".priceBOffer-required").remove()
                }
            })

            // offer value where offer checked
            $('input[name="offer"]').on("click", function() {

                if ($(this).is(":checked")) {
                    offerPerc = $('input[name="offer_percentage"]').val()

                    if (offerPerc <= 0) {
                        if ($(".offerV-required").length) {
    
                        }else {
                            $('input[name="offer_percentage"]').after(`
                            <div style="margin-top:20px" class="alert alert-outline-danger mb-4 offerV-required" role="alert"> <button type="button" class="close" data-dismiss="alert" aria-label="Close"> <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x close" data-dismiss="alert"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg></button><i class="flaticon-cancel-12 close" data-dismiss="alert"></i> ${oferrVRequired}</div>
                            `)
                        }
                    }else {
                        $(".offerV-required").remove()
                    }
                }
            })
            

            // submit form on click finish
            $(".actions ul").find('li').eq(2).on("click", 'a[href="#finish"]', function () {
                $("form").submit()
            })

    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
                <div class="row">
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                        <h4><?php echo e(__('messages.product_edit')); ?></h4>
                 </div>
        </div>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="list-unstyled mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form action="" method="post" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <div class="form-group mb-4">
                <label for=""><?php echo e(__('messages.current_images')); ?></label><br>
                <div class="row">
                <?php if(count($data['product']->images) > 0): ?>
                    <?php $__currentLoopData = $data['product']->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div style="position : relative" class="col-md-2 product_image">
                        <a onclick="return confirm('<?php echo e(__('messages.are_you_sure')); ?>')" style="position : absolute; right : 20px" href="<?php echo e(route('productImage.delete', $image->id)); ?>" class="close">x</a>
                        <img style="width: 100%" src="https://res.cloudinary.com/dz3o88rdi/image/upload/w_100,q_100/v1581928924/<?php echo e($image->image); ?>"  />
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </div>
            </div>
            <div class="statbox widget box box-shadow">
                <div class="widget-content widget-content-area">
                    <div id="circle-basic" class="">
                        <h3><?php echo e(__('messages.product_details')); ?></h3>
                        <section>
                            <div class="custom-file-container" data-upload-id="myFirstImage">
                                <label><?php echo e(__('messages.upload')); ?> (<?php echo e(__('messages.multiple_image')); ?>) * <a href="javascript:void(0)" class="custom-file-container__image-clear" title="Clear Image">x</a></label>
                                <label class="custom-file-container__custom-file" >
                                    <input type="file" required name="images[]" multiple class="custom-file-container__custom-file__custom-file-input" accept="image/*">
                                    <input type="hidden" name="MAX_FILE_SIZE" value="10485760" />
                                    <span class="custom-file-container__custom-file__custom-file-control"></span>
                                </label>
                                <div class="custom-file-container__image-preview"></div>
                            </div>
                            <div class="form-group">
                                <label for="brand"><?php echo e(__('messages.brand')); ?></label>
                                <select name="brand_id" class="form-control brand">
                                    <option value="0" selected><?php echo e(__('messages.select')); ?></option>
                                    <?php $__currentLoopData = $data['brands']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e(isset($data['product']['brand_id']) && $data['product']['brand_id'] == $brand->id ? 'selected' : ''); ?> value="<?php echo e($brand->id); ?>"><?php echo e(App::isLocale('en') ? $brand->title_en : $brand->title_ar); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="category"><?php echo e(__('messages.category')); ?></label>
                                <select id="category" name="category_id" class="form-control">
                                    <option disabled selected><?php echo e(__('messages.select')); ?></option>
                                    <?php $__currentLoopData = $data['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e($data['product']['category_id'] == $category->id ? 'selected' : ''); ?> value="<?php echo e($category->id); ?>"><?php echo e(App::isLocale('en') ? $category->title_en : $category->title_ar); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            
                            <div style="display: none" class="form-group">
                                <label for="sub_category_select"><?php echo e(__('messages.sub_category')); ?></label>
                                <select id="sub_category_select" name="sub_category_id" class="form-control">
                                </select>
                            </div>
                            <div class="form-group mb-4">
                                <label for="title_en"><?php echo e(__('messages.title_en')); ?></label>
                                <input required type="text" name="title_en" class="form-control" id="title_en" placeholder="<?php echo e(__('messages.title_en')); ?>" value="<?php echo e($data['product']['title_en']); ?>" >
                            </div>
                            <div class="form-group mb-4">
                                <label for="title_ar"><?php echo e(__('messages.title_ar')); ?></label>
                                <input required type="text" name="title_ar" class="form-control" id="title_ar" placeholder="<?php echo e(__('messages.title_ar')); ?>" value="<?php echo e($data['product']['title_ar']); ?>" >
                            </div>
                            <div class="form-group mb-4 english-direction" >
                                <label for="demo1"><?php echo e(__('messages.english')); ?></label>
                                <textarea required name="description_en" class="form-control"  rows="5"><?php echo e($data['product']['description_en']); ?></textarea>
                            </div>
                
                            <div class="form-group mb-4 arabic-direction">
                                <label for="demo2"><?php echo e(__('messages.arabic')); ?></label>
                                <textarea name="description_ar" required  class="form-control"  rows="5"><?php echo e($data['product']['description_ar']); ?></textarea>
                            </div> 
                        </section>
                        <h3><?php echo e(__('messages.product_specification')); ?> ( <?php echo e(__('messages.optional')); ?> )</h3>
                        <section>
                            <div id="category_options" style="margin-bottom: 20px; display : none" class="col-md-3" >
                                <label> <?php echo e(__('messages.options')); ?> </label>
                                <div class="row">
                                    
                                </div>  
                            </div>
                            <div id="category_options_sibling">
                                <?php if(isset($data['options']) && count($data['options']) > 0): ?>
                                    <?php for($i = 0; $i < count($data['options']); $i ++): ?>
                                    <?php if(App::isLocale('en')): ?>
                                    <div class="form-group mb-4 <?php echo e($data['options'][$i]['option_id'] . "element"); ?>">
                                        <label>English <?php echo e($data['options'][$i]['option_title_en']); ?></label>
                                        <input required type="text" name="value_en[]" class="form-control"  placeholder="" value="<?php echo e($data['options'][$i]['value_en']); ?>" >
                                    </div>
                                    <div class="form-group mb-4 <?php echo e($data['options'][$i]['option_id'] . "element"); ?>">
                                        <label >English <?php echo e($data['options'][$i]['option_title_en']); ?></label>
                                        <input required type="text" name="value_ar[]" class="form-control" placeholder="" value="<?php echo e($data['options'][$i]['value_ar']); ?>" >
                                    </div>
                                    <?php else: ?>
                                    <div class="form-group mb-4 <?php echo e($data['options'][$i]['option_id'] . "element"); ?>">
                                        <label><?php echo e($data['options'][$i]['option_title_ar']); ?> باللغة العربية</label>
                                        <input required type="text" name="value_en[]" class="form-control"  placeholder="" value="<?php echo e($data['options'][$i]['value_en']); ?>" >
                                    </div>
                                    <div class="form-group mb-4 <?php echo e($data['options'][$i]['option_id'] . "element"); ?>">
                                        <label ><?php echo e($data['options'][$i]['option_title_ar']); ?> باللغة العربية</label>
                                        <input required type="text" name="value_ar[]" class="form-control" placeholder="" value="<?php echo e($data['options'][$i]['value_ar']); ?>" >
                                    </div>
                                    <?php endif; ?>
                                    <input name="option[]" value="<?php echo e($data['options'][$i]['option_id']); ?>" type="hidden" class="new-control-input <?php echo e($data['options'][$i]['option_id'] . "element"); ?>">
                                    <?php endfor; ?>
                                <?php endif; ?>
                            </div>
                        </section>
                        <h3><?php echo e(__('messages.prices_and_inventory')); ?></h3>
                        <section>
                            <div class="form-group mb-4">
                                <label for="total_quatity"><?php echo e(__('messages.total_quatity')); ?></label>
                                <input required type="number" name="total_quatity" class="form-control" id="total_quatity" placeholder="<?php echo e(__('messages.total_quatity')); ?>" value="<?php echo e($data['product']['total_quatity']); ?>" >
                            </div>
                            <div class="form-group mb-4">
                                <label for="remaining_quantity"><?php echo e(__('messages.remaining_quantity')); ?></label>
                                <input required type="number" name="remaining_quantity" class="form-control" id="remaining_quantity" placeholder="<?php echo e(__('messages.remaining_quantity')); ?>" value="<?php echo e($data['product']['remaining_quantity']); ?>" >
                            </div>
                            <div class="form-group mb-4">
                                <label for="price_before_offer"><?php echo e(__('messages.product_price')); ?></label>
                                <input required type="number" step="any" min="0" name="price_before_offer" class="form-control" id="price_before_offer" placeholder="<?php echo e(__('messages.product_price')); ?>" value="<?php echo e($data['product']['price_before_offer'] != 0 ? $data['product']['price_before_offer'] : $data['product']['final_price']); ?>" >
                            </div>
                            <div style="margin-bottom: 20px" class="col-md-3" >
                                <div >
                                   <label class="new-control new-checkbox new-checkbox-text checkbox-primary">
                                     <input <?php echo e($data['product']['offer_percentage'] > 0 ? 'checked' : ''); ?> id="discount" name="offer" value="1" type="checkbox" class="new-control-input">
                                     <span class="new-control-indicator"></span><span class="new-chk-content"><?php echo e(__('messages.discount')); ?></span>
                                   </label>
                               </div>     
                            </div>
                            <div style="display:<?php echo e($data['product']['offer_percentage'] == 0 ? 'none' : ''); ?>" class="form-group mb-4">
                                <label for="offer_percentage"><?php echo e(__('messages.discount_value')); ?></label>
                                <input <?php echo e($data['product']['offer_percentage'] == 0 ? 'disabled' : ''); ?> type="number" step="any" min="0" name="offer_percentage" class="form-control" id="offer_percentage" placeholder="<?php echo e(__('messages.discount_value')); ?>" value="<?php echo e($data['product']['offer_percentage']); ?>" >
                            </div>
                            <div style="display:<?php echo e($data['product']['offer_percentage'] == 0 ? 'none' : ''); ?>" class="form-group mb-4">
                                <label for="final_price"><?php echo e(__('messages.price_after_discount')); ?></label>
                                <input disabled type="number" step="any" min="0" name="final_price" class="form-control" id="final_price" placeholder="<?php echo e(__('messages.price_after_discount')); ?>" value="<?php echo e($data['product']['final_price']); ?>" >
                            </div>
                            <div class="form-group mb-4">
                                <label for="stored_number"><?php echo e(__('messages.product_stored_number')); ?></label>
                                <input type="text" name="stored_number" class="form-control" id="stored_number" placeholder="<?php echo e(__('messages.product_stored_number')); ?>" value="<?php echo e(empty($data['product']['stored_number']) ? '' : $data['product']['stored_number']); ?>" >
                            </div>
                            <div class="form-group mb-4">
                                <label for="title_en"><?php echo e(__('messages.barcode')); ?></label>
                                <input required type="text" name="barcode" class="form-control" id="barcode" placeholder="<?php echo e(__('messages.barcode')); ?>" value="<?php echo e(empty($data['product']['barcode']) ? $data['barcode'] : $data['product']['barcode']); ?>" >
                            </div>
                             <?php if(count($data['Home_sections']) > 0): ?>
                            <div style="margin-bottom: 20px" class="col-md-3" >
                                <div >
                                <label class="new-control new-checkbox new-checkbox-text checkbox-primary">
                                    <input id="add_home" <?php echo e(count($data['elements']) > 0 ? 'checked' : ''); ?> value="1" type="checkbox" class="new-control-input">
                                    <span class="new-control-indicator"></span><span class="new-chk-content"><?php echo e(__('messages.add_product_to_home_section')); ?></span>
                                </label>
                            </div>     
                            </div>

                            <div style="display: <?php echo e(count($data['elements']) > 0 ? '' : 'none'); ?>" class="form-group">
                                <label for="home_section"><?php echo e(__('messages.home_section')); ?></label>
                                <select  id="home_section" name="home_section" class="form-control">
                                    <option value="0" selected><?php echo e(__('messages.select')); ?></option>
                                    <?php $__currentLoopData = $data['Home_sections']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option <?php echo e((in_array($section->id , $data['elements'])? 'selected' : '')); ?> value="<?php echo e($section->id); ?>"><?php echo e(App::isLocale('en') ? $section->title_en : $section->title_ar); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <?php endif; ?> 

                        </section>
                    </div>
        
                </div>
            </div>

        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/ecommerce.u-smart.co/resources/views/admin/product_edit.blade.php ENDPATH**/ ?>
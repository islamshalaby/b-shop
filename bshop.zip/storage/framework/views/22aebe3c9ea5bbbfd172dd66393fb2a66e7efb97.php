<?php $__env->startSection('title' , __('messages.user_details')); ?>

<?php $__env->startSection('content'); ?>

        <div id="tableSimple" class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.user_details')); ?></h4>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div class="table-responsive"> 
                <table class="table table-bordered mb-4">
                    <tbody>
                    
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.user_name')); ?></td>
                                <td><?php echo e($data['user']['name']); ?></td>
                            </tr>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.user_phone')); ?> </td>
                                <td><?php echo e($data['user']['phone']); ?></td>
                            </tr>
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.user_email')); ?> </td>
                                <td> <?php echo e($data['user']['email']); ?> </td>
                            </tr>
                           
                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.created_at')); ?> </td>
                                <td> <?php echo e($data['user']['created_at']); ?> </td>
                            </tr>

                            <tr>
                                <td class="label-table" > <?php echo e(__('messages.status')); ?> </td>
                                <td> 
                                    <?php if($data['user']['active']): ?>
                                        <span class="text-success margin-15" >
                                            <?php echo e(__('messages.actived')); ?>

                                        </span>
                                        <a href="/admin-panel/users/block/<?php echo e($data['user']['id']); ?>">
                                            <span class="badge badge-danger"><?php echo e(__('messages.block')); ?></span>
                                        </a>
                                    <?php else: ?>
                                        <span class="text-danger margin-15" >
                                            <?php echo e(__('messages.blocked')); ?>

                                        </span>
                                        <a href="/admin-panel/users/active/<?php echo e($data['user']['id']); ?>">
                                            <span class="badge badge-success"><?php echo e(__('messages.active')); ?></span>
                                        </a>
                                    <?php endif; ?>                                
                                </td>
                            </tr>
                            
                    </tbody>
                </table>
            </div>


                <?php if(session('error')): ?>
                    <div class="alert alert-danger mb-4" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">x</button>
                        <strong>Error!</strong> <?php echo e(session('error')); ?> </button>
                    </div> 
                <?php endif; ?>    

                <?php if(session('status')): ?>
                    <div class="alert alert-success mb-4" role="alert">
                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">x</button>
                        <strong>Success!</strong> <?php echo e(session('status')); ?> </button>
                    </div> 
                <?php endif; ?>

                <div class="">
                     <h4><?php echo e(__('messages.send_notification_to_user')); ?></h4>
                </div>
                <br>
                <form action="/admin-panel/users/send_notifications/<?php echo e($data['user']['id']); ?>" method="post" enctype="multipart/form-data" >
                    <?php echo csrf_field(); ?>
                    <div class="form-group mb-4">
                        <label for="image"><?php echo e(__('messages.image')); ?></label>
                        <input type="file" name="image" class="form-control" id="image" placeholder="<?php echo e(__('messages.image')); ?>" value="" >
                    </div>                
                    <div class="form-group mb-4">
                        <label for="title"><?php echo e(__('messages.notification_title')); ?></label>
                        <input required type="text" name="title" class="form-control" id="title" placeholder="<?php echo e(__('messages.notification_title')); ?>" value="" >
                    </div>
                    <div class="form-group mb-4">
                        <label for="body"><?php echo e(__('messages.notification_body')); ?></label>
                        <input required type="text" name="body" class="form-control" id="body" placeholder="<?php echo e(__('messages.notification_body')); ?>" value="" >
                    </div>
                    <input type="submit" value="<?php echo e(__('messages.submit')); ?>" class="btn btn-primary">
                </form>

                

        </div>
    </div>  

<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/ecommerce.u-smart.co/resources/views/admin/user_details.blade.php ENDPATH**/ ?>
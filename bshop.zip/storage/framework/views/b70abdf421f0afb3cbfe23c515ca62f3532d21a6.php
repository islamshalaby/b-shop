<?php $__env->startSection('title' , __('messages.add_new_home_section')); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        var ss = $(".tags").select2({
            tags: true,
        });
        var language = "<?php echo e(Config::get('app.locale')); ?>"
        $("#type").on("change", function() {
            if ($(this).val() == 1 || $(this).val() == 5) {
                $("#ads_check").html('')
                var section = 'ads[]',
                    selection = 'checkbox'
                if ($(this).val() == 5) {
                    section = 'ad'
                    selection = 'radio'
                }
                $.ajax({
                    url : "/admin-panel/home_sections/fetch/" + $(this).val(),
                    type : 'GET',
                    success : function (data) {
                        $("#ads_check").show()
                        $("#ads_check").prop("disabled", false)
                        $("#categoriesList").parent(".form-group").hide()
                        $("#categoriesList").prop("disabled", true)
                        $("#categoriesList").empty()
                        $("#offers_check").parent(".form-group").hide()
                        $("#offers_check").prop("disabled", true)
                        $("#offers_check").empty()
                        $("#brandsList").parent(".form-group").hide()
                        $("#brandsList").prop("disabled", true)
                        $("#brandsList").empty()
                        data.forEach(function(ad) {
                            $("#ads_check").append(`
                                <div class="col-md-3" >
                                    <div >
                                        <label class="new-control new-checkbox new-checkbox-text checkbox-primary">
                                            <input name="${section}" value="${ad.id}" type="${selection}" class="new-control-input">
                                            <span class="new-control-indicator"></span><span class="new-chk-content"><img src="https://res.cloudinary.com/dz3o88rdi/image/upload/w_100,q_100/v1581928924/${ad.image}" /></span>
                                        </label>
                                    </div>     
                                </div>
                            `)
                        })
                        
                    }
                })
            }else if ($(this).val() == 2) {
                $("#categoriesList").html('')
                $.ajax({
                    url : "/admin-panel/home_sections/fetch/2",
                    type : 'GET',
                    success : function (data) {
                        $("#ads_check").prop("disabled", true)
                        $("#ads_check").hide()
                        $("#ads_check").empty()
                        $("#brandsList").prop("disabled", true)
                        $("#brandsList").parent(".form-group").hide()
                        $("#brandsList").empty()
                        $("#offers_check").parent(".form-group").hide()
                        $("#offers_check").prop("disabled", true)
                        $("#offers_check").empty()
                        $("#categoriesList").prop("disabled", false)
                        $("#categoriesList").parent(".form-group").show()
                        data.forEach(function(category) {
                            var categoryName = category.title_en

                            if (language == 'ar') {
                                categoryName = category.title_ar
                            }
                            $("#categoriesList").append(`
                                <option value="${category.id}" >${categoryName}</option>
                            `)
                        })
                        
                    }
                })
            }else if($(this).val() == 3) {
                $("#brandsList").html('')
                $.ajax({
                    url : "/admin-panel/home_sections/fetch/3",
                    type : 'GET',
                    success : function (data) {
                        $("#ads_check").prop("disabled", true)
                        $("#ads_check").hide()
                        $("#ads_check").empty()
                        $("#offers_check").parent(".form-group").hide()
                        $("#offers_check").prop("disabled", true)
                        $("#offers_check").empty()
                        $("#categoriesList").prop("disabled", true)
                        $("#categoriesList").parent(".form-group").hide()
                        $("#categoriesList").empty()
                        $("#brandsList").parent(".form-group").show()
                        $("#brandsList").prop("disabled", false)
                        data.forEach(function(brand) {
                            var brandName = brand.title_en

                            if (language == 'ar') {
                                brandName = brand.title_ar
                            }
                            $("#brandsList").append(`
                                <option value="${brand.id}" >${brand.title_en}</option>
                            `)
                        })
                        
                    }
                })
            }else if ($(this).val() == 4) {
                $("#offers_check").html('')
                $.ajax({
                    url : "/admin-panel/home_sections/fetch/4",
                    type : 'GET',
                    success : function (data) {
                        $("#offers_check").parent(".form-group").show()
                        $("#offers_check").prop("disabled", false)
                        $("#ads_check").hide()
                        $("#ads_check").prop("disabled", true)
                        $("#ads_check").empty()
                        $("#categoriesList").parent(".form-group").hide()
                        $("#categoriesList").prop("disabled", true)
                        $("#categoriesList").empty()
                        $("#brandsList").parent(".form-group").hide()
                        $("#brandsList").prop("disabled", true)
                        $("#brandsList").empty()
                        console.log(data)
                        data.forEach(function(offer) {
                            var offerName = offer.title_en

                            if (language == 'ar') {
                                offerName = offer.title_ar
                            }
                            $("#offers_check").append(`
                            <option value="${offer.id}" >${offerName}</option>
                            `)
                        })
                        
                    }
                })
            }
        })
        
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
                <div class="row">
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                        <h4><?php echo e(__('messages.add_new_home_section')); ?></h4>
                 </div>
        </div>
        <form action="" method="post" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
                    
            <div class="form-group mb-4">
                <label for="title_en"><?php echo e(__('messages.title_en')); ?></label>
                <input required type="text" name="title_en" class="form-control" id="title_en" placeholder="<?php echo e(__('messages.title_en')); ?>" value="" >
            </div>
            <div class="form-group mb-4">
                <label for="title_ar"><?php echo e(__('messages.title_ar')); ?></label>
                <input required type="text" name="title_ar" class="form-control" id="title_ar" placeholder="<?php echo e(__('messages.title_ar')); ?>" value="" >
            </div>
            <div class="form-group mb-4">
                <label for="sort"><?php echo e(__('messages.sort')); ?></label>
                <input required type="number" name="sort" class="form-control" id="sort" placeholder="<?php echo e(__('messages.sort')); ?>" value="" >
            </div>
            
            <div class="form-group">
                <label for="type"><?php echo e(__('messages.section_type')); ?></label>
                <select id="type" name="type" class="form-control">
                    <option selected><?php echo e(__('messages.select')); ?></option>
                    <option value="1"><?php echo e(__('messages.ads')); ?></option>
                    <option value="2"><?php echo e(__('messages.categories')); ?></option>
                    <option value="3"><?php echo e(__('messages.brands')); ?></option>
                    <option value="4"><?php echo e(__('messages.offers')); ?></option>
                    <option value="5"><?php echo e(__('messages.ad')); ?></option>
                </select>
            </div>
            <div style="display: none" id="ads_check" class="row" >
                <div class="col-12" >
                    <label> <?php echo e(__('messages.ads')); ?> </label>
                </div>
                
            </div>
            <div style="display : none" class="form-group" >
                <div class="col-12" >
                    <label> <?php echo e(__('messages.categories')); ?> </label>
                </div>
                <select id="categoriesList" name="categories[]" class="form-control tags" multiple="multiple">
                </select>
            </div>
            <div style="display : none" class="form-group" >
                <div class="col-12" >
                    <label> <?php echo e(__('messages.brands')); ?> </label>
                </div>
                <select id="brandsList" name="brands[]" class="form-control tags" multiple="multiple">
                </select>
            </div>
            
            <div style="display: none" class="form-group" >
                
                <label> <?php echo e(__('messages.offers')); ?> </label>
                
                <select id="offers_check" name="offers[]" class="form-control tags" multiple="multiple">
                </select>
                
            </div>
            
            <input type="submit" value="<?php echo e(__('messages.submit')); ?>" class="btn btn-primary">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/ecommerce.u-smart.co/resources/views/admin/home_section_form.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title' , __('messages.product_details')); ?>

<?php $__env->startSection('content'); ?>
        <div id="tableSimple" class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.product_details')); ?></h4>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div class="table-responsive"> 
                <table class="table table-bordered mb-4">
                    <tbody>
                        <tr>
                            <td class="label-table" > <?php echo e(__('messages.title_en')); ?></td>
                            <td>
                                <?php echo e($data['product']['title_en']); ?>

                            </td>
                        </tr>
                        <tr>
                            <td class="label-table" > <?php echo e(__('messages.title_ar')); ?></td>
                            <td>
                                <?php echo e($data['product']['title_ar']); ?>

                            </td>
                        </tr>
                        <tr>
                            <td class="label-table" > <?php echo e(__('messages.category')); ?> </td>
                            <td>
                                <a target="_blank" href="<?php echo e(route('categories.details', $data['product']['category']['id'])); ?>">
                                    <?php echo e(App::isLocale('en') ? $data['product']['category']['title_en'] : $data['product']['category']['title_ar']); ?>

                                </a>
                            </td>
                        </tr>
                        <?php if($data['product']['brand_id'] > 0): ?>
                        <tr>
                            <td class="label-table" > <?php echo e(__('messages.brand')); ?> </td>
                            <td>
                                <a target="_blank" href="<?php echo e(route('brands.details', $data['product']['brand']['id'])); ?>">
                                <?php echo e(App::isLocale('en') ? $data['product']['brand']['title_en'] : $data['product']['brand']['title_ar']); ?>

                                </a>
                            </td>
                        </tr>
                        <?php endif; ?>
                        
                        <tr>
                            <td class="label-table" > <?php echo e(__('messages.sub_category')); ?> </td>
                            <td>
                                <a target="_blank" href="<?php echo e(route('sub_categories.details', $data['product']['subCategory']['id'])); ?>">
                                <?php echo e(App::isLocale('en') ? $data['product']['subCategory']['title_en'] : $data['product']['subCategory']['title_ar']); ?>

                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td class="label-table" > <?php echo e(__('messages.description_en')); ?> </td>
                            <td>
                                <?php echo e($data['product']['description_en']); ?>

                            </td>
                        </tr>
                        <tr>
                            <td class="label-table" > <?php echo e(__('messages.total_quatity')); ?> </td>
                            <td>
                                <?php echo e($data['product']['total_quatity']); ?>

                            </td>
                        </tr>
                         <tr>
                            <td class="label-table" > <?php echo e(__('messages.remaining_quantity')); ?> </td>
                            <td>
                                <?php echo e($data['product']['remaining_quantity']); ?>

                            </td>
                        </tr>
                        <tr>
                            <td class="label-table" > <?php echo e(__('messages.sold_quantity')); ?> </td>
                            <td>
                                <?php echo e($data['product']['sold_count']); ?>

                            </td>
                        </tr>
               
                        <tr>
                            <td class="label-table" > <?php echo e(__('messages.product_price')); ?> </td>
                            <td>
                                <?php echo e($data['product']['final_price']); ?> <?php echo e(__('messages.dinar')); ?>

                            </td>
                        </tr>  
                        <?php if($data['product']['offer'] == 1): ?>
                        <tr>
                            <td class="label-table" > <?php echo e(__('messages.price_before_discount')); ?> </td>
                            <td>
                                <?php echo e($data['product']['price_before_offer']); ?> <?php echo e(__('messages.dinar')); ?>

                            </td>
                        </tr> 
                        <?php endif; ?>
                            
                        <tr>
                            <td class="label-table" > <?php echo e(__('messages.last-update_date')); ?> </td>
                            <td>
                                <?php echo e($data['product']['updated_at']->format('Y-m-d')); ?>

                            </td>
                        </tr>             
                    </tbody>
                </table>
                <?php if(isset($data['options']) && count($data['options']) > 0): ?>
                <h5><?php echo e(__('messages.options')); ?></h5>
                <table class="table table-bordered mb-4">
                    <tbody>
                        <?php $__currentLoopData = $data['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="label-table" > <?php echo e(App::isLocale('en') ? $option['option_title_en'] : $option['option_title_ar']); ?></td>
                            <td>
                                <?php echo e(App::isLocale('en') ? $option['value_en'] : $option['value_ar']); ?>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>           
                    </tbody>
                </table>
                <?php endif; ?>

                <div class="row">
                    <?php if(count($data['product']['images']) > 0): ?>
                        <?php $__currentLoopData = $data['product']['images']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div style="position : relative" class="col-md-2 product_image">
                            <img width="100%" src="https://res.cloudinary.com/dz3o88rdi/image/upload/w_100,q_100/v1581928924/<?php echo e($image->image); ?>"  />
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div style="text-align:center" >
                    <br>
                    <a href="#" data-toggle="modal" data-target="#zoomupModal<?php echo e($data['product']['id']); ?>" class="btn btn-<?php echo e($data['product']['remaining_quantity'] == 0 ? 'danger' : 'primary'); ?>"><?php echo e(__('messages.add_quantity')); ?></a>
                </div>

                <div id="zoomupModal<?php echo e($data['product']['id']); ?>" class="modal animated zoomInUp custo-zoomInUp" role="dialog">
                    <div class="modal-dialog">
                        <!-- Modal content-->
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title"><?php echo e(App::isLocale('en') ? $data['product']['title_en'] : $data['product']['title_ar']); ?></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('update.quantity', $data['product']['id'])); ?>" method="post" enctype="multipart/form-data" >
                                    <?php echo csrf_field(); ?>    
                                    <div class="form-group mb-4">
                                        <label for="remaining_quantity"><?php echo e(__('messages.quantity')); ?></label>
                                        <input required type="text" name="remaining_quantity" class="form-control" id="remaining_quantity" placeholder="<?php echo e(__('messages.quantity')); ?>" value="" >
                                    </div>
                        
                                    <input type="submit" value="<?php echo e(__('messages.add')); ?>" class="btn btn-primary">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>  
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/ecommerce.u-smart.co/resources/views/admin/product_details.blade.php ENDPATH**/ ?>
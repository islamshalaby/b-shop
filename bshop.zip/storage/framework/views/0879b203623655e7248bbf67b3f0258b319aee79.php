<?php $__env->startSection('title' , __('messages.show_products')); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .table > tbody > tr > td,
        .table > thead > tr > th {
            font-size : 10px
        }
        .dropdown-menu {
            height: 100px;
            overflow: auto
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script src="/admin/plugins/table/datatable/custom_miscellaneous.js"></script>
    <script>
        var language = "<?php echo e(Config::get('app.locale')); ?>",
            select = "<?php echo e(__('messages.select')); ?>",
            details = "<?php echo e(__('messages.details')); ?>",
            edit = "<?php echo e(__('messages.edit')); ?>",
            delte = "<?php echo e(__('messages.delete')); ?>"
        $("#category").on("change", function () {
            console.log("test2")
            var categoryId = $(this).val()
            

            dTbls.clear().draw();
            
            $.ajax({
                url : "fetchcategoryproducts/" + categoryId,
                type : 'GET',
                success : function (data) {
                    var i = 1
                    data.forEach(function(element) {
                        console.log("in")
                        var elementName = element.title_en,
                            cat = element.category.title_en
                        if (language == 'ar') {
                            elementName = element.title_ar
                            cat = element.category.title_ar
                           
                        }
                        
                        var permition = [],
                            detailsLink = "/admin-panel/products/details/" + element.id,
                            editLink = "/admin-panel/products/edit/" + element.id,
                            deleteLink = "/admin-panel/products/delete/" + element.id,
                            dinar = "<?php echo e(__('messages.dinar')); ?>",
                            visibilityStatus = "<?php echo e(__('messages.visible')); ?>",
                            hideShoProduct = "<?php echo e(__('messages.hide_product')); ?>",
                            hideShowLink = "/admin-panel/products/hide/" + element.id + "/" + 1

                            if (element.hidden == 1) {
                                hideShoProduct = "<?php echo e(__('messages.show_product')); ?>"
                                hideShowLink = "/admin-panel/products/hide/" + element.id + "/" + 0
                                visibilityStatus = "<?php echo e(__('messages.hidden')); ?>"
                            }
                        <?php if(Auth::user()->update_data): ?> 
                        permition[0] = `<a class="dropdown-item" href="${editLink}">${edit}</a>`
                        <?php endif; ?>
                        <?php if(Auth::user()->delete_data): ?> 
                        permition[1] = `<a class="dropdown-item"  onclick='return confirm("<?php echo e(__('messages.are_you_sure')); ?>");' href="${deleteLink}">${delte}</a>`
                        permition[2] = `<a class="dropdown-item" onclick='return confirm("<?php echo e(__('messages.are_you_sure')); ?>");' href="${hideShowLink}">${hideShoProduct}</a>`
                        <?php endif; ?>
                        $("#html5-extension tbody").parent('.form-group').show()
                        console.log("before")
                        var rowNode = dTbls.row.add( [
                            `${i}`,
                            `<img src="https://res.cloudinary.com/dagdz3cnk/image/upload/w_50,q_50/v1581928924/${ (element.images[0].image) ? element.images[0].image : '' }"  />`,
                            `${elementName}`,
                            `${cat}`,
                            `${element.total_quatity}`,
                            `${element.remaining_quantity}`,
                            `${element.sold_count}`,
                            `${element.price_before_offer} ${dinar}`,
                            `${element.final_price} ${dinar}`,
                            `${element.updated_at}`,
                            `${element.barcode}`,
                            `<td class="hide_col">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-dark btn-sm">${visibilityStatus}</button>
                                    <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuReference5" style="will-change: transform;">
                                      <a class="dropdown-item" href="${detailsLink}">${details}</a>
                                      ${(permition[0]) ? permition[0] : ''}
                                      ${(permition[1]) ? permition[1] : ''} 
                                      <div class="dropdown-divider"></div>
                                      ${(permition[2]) ? permition[2] : ''}
                                    </div>
                                  </div>
                            </td>`
                        ] ).draw().node();

                        $( rowNode ).find('td').eq(1).addClass('hide_col');
                       
                        $( rowNode ).find('td').eq(10).addClass('hide_col');
                        i ++
                    })
                    
                }
            })
            
            $("#sub_category_select").html("")
            $.ajax({
                url : "fetchsubcategorybycategory/" + categoryId,
                type : 'GET',
                success : function (data) {
                    $("#sub_category_select").prepend(`
                            <option selected disabled>${select}</option>
                        `)
                        
                    data.forEach(function(element) {
                        var elementName = element.title_en
                        if (language == 'ar') {
                            elementName = element.title_ar
                        }
                        
                        $("#sub_category_select").parent('.form-group').show()
                        $("#sub_category_select").append(`
                            <option value="${element.id}">${elementName}</option>
                        `)
                    })
                }
            })

        })

        $("#brand").on("change", function () {
            
            var brandId = $(this).val()
            

            dTbls.clear().draw();
            
            $.ajax({
                url : "fetchbrandproducts/" + brandId,
                type : 'GET',
                success : function (data) {
                    var i = 1
                    data.forEach(function(element) {
                        
                        var elementName = element.title_en,
                            cat = element.category.title_en
                        if (language == 'ar') {
                            elementName = element.title_ar
                            cat = element.category.title_ar
                           
                        }
                        
                        var permition = [],
                            detailsLink = "/admin-panel/products/details/" + element.id,
                            editLink = "/admin-panel/products/edit/" + element.id,
                            deleteLink = "/admin-panel/products/delete/" + element.id,
                            dinar = "<?php echo e(__('messages.dinar')); ?>",
                            visibilityStatus = "<?php echo e(__('messages.visible')); ?>",
                            hideShoProduct = "<?php echo e(__('messages.hide_product')); ?>",
                            hideShowLink = "/admin-panel/products/hide/" + element.id + "/" + 1

                            if (element.hidden == 1) {
                                hideShoProduct = "<?php echo e(__('messages.show_product')); ?>"
                                hideShowLink = "/admin-panel/products/hide/" + element.id + "/" + 0
                                visibilityStatus = "<?php echo e(__('messages.hidden')); ?>"
                            }
                        <?php if(Auth::user()->update_data): ?> 
                        permition[0] = `<a class="dropdown-item" href="${editLink}">${edit}</a>`
                        <?php endif; ?>
                        <?php if(Auth::user()->delete_data): ?> 
                        permition[1] = `<a class="dropdown-item"  onclick='return confirm("<?php echo e(__('messages.are_you_sure')); ?>");' href="${deleteLink}">${delte}</a>`
                        permition[2] = `<a class="dropdown-item" onclick='return confirm("<?php echo e(__('messages.are_you_sure')); ?>");' href="${hideShowLink}">${hideShoProduct}</a>`
                        <?php endif; ?>
                        $("#html5-extension tbody").parent('.form-group').show()
                        
                        var rowNode = dTbls.row.add( [
                            `${i}`,
                            `<img src="https://res.cloudinary.com/dagdz3cnk/image/upload/w_50,q_50/v1581928924/${ (element.images[0].image) ? element.images[0].image : '' }"  />`,
                            `${elementName}`,
                            `${cat}`,
                            `${element.total_quatity}`,
                            `${element.remaining_quantity}`,
                            `${element.sold_count}`,
                            `${element.price_before_offer} ${dinar}`,
                            `${element.final_price} ${dinar}`,
                            `${element.updated_at}`,
                            `${element.barcode}`,
                            `<td class="hide_col">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-dark btn-sm">${visibilityStatus}</button>
                                    <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuReference5" style="will-change: transform;">
                                      <a class="dropdown-item" href="${detailsLink}">${details}</a>
                                      ${(permition[0]) ? permition[0] : ''}
                                      ${(permition[1]) ? permition[1] : ''} 
                                      <div class="dropdown-divider"></div>
                                      ${(permition[2]) ? permition[2] : ''} 
                                    </div>
                                  </div>
                            </td>`
                        ] ).draw().node();

                        $( rowNode ).find('td').eq(1).addClass('hide_col');
                        
                        $( rowNode ).find('td').eq(10).addClass('hide_col');
                        i ++
                    })
                    
                }
            })

        })

        

        $("#sub_category_select").on("change", function () {
            dTbls.clear().draw();
            var subCategoryId = $(this).val()
            $.ajax({
                url : "fetchproducts/" + subCategoryId,
                type : 'GET',
                success : function (data) {
                    var i = 1
                    data.forEach(function(element) {
                        var elementName = element.title_en,
                            cat = element.category.title_en
                        if (language == 'ar') {
                            elementName = element.title_ar
                            cat = element.category.title_ar
                           
                        }
                        
                        var permition = [],
                            detailsLink = "/admin-panel/products/details/" + element.id,
                            editLink = "/admin-panel/products/edit/" + element.id,
                            deleteLink = "/admin-panel/products/delete/" + element.id,
                            dinar = "<?php echo e(__('messages.dinar')); ?>",
                            visibilityStatus = "<?php echo e(__('messages.visible')); ?>",
                            hideShoProduct = "<?php echo e(__('messages.hide_product')); ?>",
                            hideShowLink = "/admin-panel/products/hide/" + element.id + "/" + 1

                            if (element.hidden == 1) {
                                hideShoProduct = "<?php echo e(__('messages.show_product')); ?>"
                                hideShowLink = "/admin-panel/products/hide/" + element.id + "/" + 0
                                visibilityStatus = "<?php echo e(__('messages.hidden')); ?>"
                            }
                        <?php if(Auth::user()->update_data): ?> 
                        permition[0] = `<a class="dropdown-item" href="${editLink}">${edit}</a>`
                        <?php endif; ?>
                        <?php if(Auth::user()->delete_data): ?> 
                        permition[1] = `<a class="dropdown-item"  onclick='return confirm("<?php echo e(__('messages.are_you_sure')); ?>");' href="${deleteLink}">${delte}</a>`
                        permition[2] = `<a class="dropdown-item" onclick='return confirm("<?php echo e(__('messages.are_you_sure')); ?>");' href="${hideShowLink}">${hideShoProduct}</a>`
                        <?php endif; ?>
                        $("#html5-extension tbody").parent('.form-group').show()
                        
                        
                        var rowNode = dTbls.row.add( [
                            `${i}`,
                            `<img src="https://res.cloudinary.com/dagdz3cnk/image/upload/w_50,q_50/v1581928924/${ (element.images[0].image) ? element.images[0].image : '' }"  />`,
                            `${elementName}`,
                            `${cat}`,
                            `${element.total_quatity}`,
                            `${element.remaining_quantity}`,
                            `${element.sold_count}`,
                            `${element.price_before_offer} ${dinar}`,
                            `${element.final_price} ${dinar}`,
                            `${element.updated_at}`,
                            `${element.barcode}`,
                            `<td class="hide_col">
                                <div class="btn-group">
                                    <button type="button" class="btn btn-dark btn-sm">${visibilityStatus}</button>
                                    <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                                      <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                    </button>
                                    <div class="dropdown-menu" aria-labelledby="dropdownMenuReference5" style="will-change: transform;">
                                      <a class="dropdown-item" href="${detailsLink}">${details}</a>
                                      ${(permition[0]) ? permition[0] : ''}
                                      ${(permition[1]) ? permition[1] : ''} 
                                      <div class="dropdown-divider"></div>
                                      ${(permition[2]) ? permition[2] : ''} 
                                    </div>
                                  </div>
                            </td>`
                            
                        ] ).draw().node();

                        $( rowNode ).find('td').eq(1).addClass('hide_col');
                        
                        $( rowNode ).find('td').eq(10).addClass('hide_col');
                        
                        i ++
                    })
                    
                    
                }
            })
        })
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div id="badgeCustom" class="col-lg-12 mx-auto layout-spacing">
    <div class="statbox widget box box-shadow">
        <div class="widget-content widget-content-area">
            <div class="row">
                <div class="form-group col-md-4">
                    <label for="category"><?php echo e(__('messages.category')); ?></label>
                    <select required id="category" name="category" class="form-control">
                        <option disabled selected><?php echo e(__('messages.select')); ?></option>
                        <?php $__currentLoopData = $data['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>"><?php echo e(App::isLocale('en') ? $category->title_en : $category->title_ar); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </select>
                </div>
                
                <div style="display: none" class="form-group col-md-4">
                    <label for="sub_category_select"><?php echo e(__('messages.sub_category')); ?></label>
                    <select required id="sub_category_select" name="sub_category" class="form-control">
                        <option disabled selected><?php echo e(__('messages.select')); ?></option>
                    </select>
                </div>

                <div class="form-group col-md-4">
                    <label for="brand"><?php echo e(__('messages.brand')); ?></label>
                    <select required id="brand" name="brand" class="form-control">
                        <option disabled selected><?php echo e(__('messages.select')); ?></option>
                        <?php $__currentLoopData = $data['brands']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($brand->id); ?>"><?php echo e(App::isLocale('en') ? $brand->title_en : $brand->title_ar); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                    </select>
                </div>
            </div>
            <?php if($data['expire'] == 'no'): ?>
            <a class="btn btn-primary" href="/admin-panel/products/show?expire=soon"><?php echo e(__('messages.expired_soon')); ?></a>
            <?php endif; ?>

            <?php if($data['expire'] == 'soon'): ?>
            <a class="btn btn-primary" href="/admin-panel/products/show"><?php echo e(__('messages.return_all_products')); ?></a>
            <?php endif; ?>            
        </div>
        
    <div id="tableSimple" class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.show_products')); ?>

                        <button data-show="0" class="btn btn-primary show_actions"><?php echo e(__('messages.hide_actions')); ?></button>
                    </h4>
                    
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div class="table-responsive"> 
                <table id="html5-extension" class="table table-hover non-hover">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th class="hide_col"><?php echo e(__('messages.image')); ?></th>
                            <th><?php echo e(__('messages.product_title')); ?></th>
                            <th><?php echo e(__('messages.category')); ?></th>
                            <th><?php echo e(__('messages.total_quatity')); ?></th>
                            <th><?php echo e(__('messages.remaining_quantity')); ?></th>
                            <th><?php echo e(__('messages.sold_quantity')); ?></th>
                            <th><?php echo e(__('messages.price_before_discount')); ?></th>
                            <th><?php echo e(__('messages.price_after_discount')); ?></th>
                            <th><?php echo e(__('messages.last-update_date')); ?></th>
                            <th><?php echo e(__('messages.barcode')); ?></th>
                            <th class="text-center hide_col"><?php echo e(__('messages.actions')); ?></th> 
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?=$i;?></td>
                                <td class="hide_col"><img src="https://res.cloudinary.com/dagdz3cnk/image/upload/w_50,q_50/v1581928924/<?php echo e(isset($product->images[0]->image) ? $product->images[0]->image : ''); ?>"  /></td>
                                <td><?php echo e(App::isLocale('en') ? $product->title_en : $product->title_ar); ?></td>
                                <td><?php echo e(App::isLocale('en') ?  $product->category->title_en : $product->category->title_ar); ?></td>
                                <td><?php echo e($product->total_quatity); ?></td>
                                <td><?php echo e($product->remaining_quantity); ?></td>
                                <td><?php echo e($product->sold_count); ?></td>
                                <td><?php echo e($product->offer == 1 ? $product->price_before_offer . " " . __('messages.dinar') : $product->final_price . " " . __('messages.dinar')); ?></td>
                                <td><?php echo e($product->final_price . " " . __('messages.dinar')); ?></td>
                                <td><?php echo e($product->updated_at->format("d-m-y")); ?></td>
                                <td><?php echo e($product->barcode); ?></td>
                                <td class="hide_col">
                                    <div class="btn-group">
                                        <button type="button" class="btn btn-dark btn-sm">
                                            <?php echo e($product->hidden == 0 ? __('messages.visible') : __('messages.hidden')); ?>

                                        </button>
                                        <button type="button" class="btn btn-dark btn-sm dropdown-toggle dropdown-toggle-split" id="dropdownMenuReference5" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" data-reference="parent">
                                          <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-chevron-down"><polyline points="6 9 12 15 18 9"></polyline></svg>
                                        </button>
                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuReference5" style="will-change: transform;">
                                          <a class="dropdown-item" href="<?php echo e(route('products.details', $product->id)); ?>"><?php echo e(__('messages.details')); ?></a>
                                            <?php if(Auth::user()->update_data): ?> 
                                            <a class="dropdown-item" href="<?php echo e(route('products.edit', $product->id)); ?>"><?php echo e(__('messages.edit')); ?></a>
                                            <?php endif; ?>
                                            <?php if(Auth::user()->delete_data): ?> 
                                            <a class="dropdown-item"  onclick='return confirm("<?php echo e(__('messages.are_you_sure')); ?>");' href="<?php echo e(route('products.delete', $product->id)); ?>"><?php echo e(__('messages.delete')); ?></a>
                                             
                                          <div class="dropdown-divider"></div>
                                          <?php if($product->hidden == 0): ?>
                                          <a class="dropdown-item" onclick='return confirm("<?php echo e(__('messages.are_you_sure')); ?>");' href="<?php echo e(route('products.visibility.status', [$product->id, 1])); ?>"><?php echo e(__('messages.hide_product')); ?></a>
                                          <?php else: ?>
                                          <a class="dropdown-item" onclick='return confirm("<?php echo e(__('messages.are_you_sure')); ?>");' href="<?php echo e(route('products.visibility.status', [$product->id, 0])); ?>"><?php echo e(__('messages.show_product')); ?></a>
                                          <?php endif; ?>
                                          <?php endif; ?> 
                                        </div>
                                      </div>
                                </td>
                                                                
                                <?php $i++; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                    <td></td>    
                    <tfoot>
                </table>
            </div>
        </div>
        
        
    </div>  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/Bshop.u-smart.co/resources/views/admin/products.blade.php ENDPATH**/ ?>
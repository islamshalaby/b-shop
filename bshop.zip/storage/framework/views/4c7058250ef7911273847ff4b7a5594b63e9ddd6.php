<?php $__env->startSection('title' , __('messages.show_home_sections')); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://code.jquery.com/ui/1.10.4/jquery-ui.js" type="text/javascript"></script>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $("tbody#sortable").sortable({
        items : "tr",
        placeholder : "ui-state-hightlight",
        update : function () {
            var ids = $('tbody#sortable').sortable("serialize");
            var url = "<?php echo e(route('home_sections.sort')); ?>";
            
            $.post(url , ids + "&_token=<?php echo e(csrf_token()); ?>");
    
            //  console.log(ids);
    
    
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div id="tableSimple" class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.show_home_sections') . " ( " . __('messages.drag&drop') . " )"); ?></h4>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div class="table-responsive"> 
                <table id="without-print" class="table table-hover non-hover" style="width:100%">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th><?php echo e(__('messages.home_section_title')); ?></th>
                            <th class="text-center"><?php echo e(__('messages.details')); ?></th>
                            <?php if(Auth::user()->update_data): ?> 
                                <th class="text-center"><?php echo e(__('messages.edit')); ?></th>                          
                            <?php endif; ?>
                            <?php if(Auth::user()->delete_data): ?> 
                                <th class="text-center"><?php echo e(__('messages.delete')); ?></th>                          
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody id="sortable">
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $data['home_sections']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $home_section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr  id="id_<?php echo e($home_section['id']); ?>">
                                <td><?=$i;?></td>
                                <td><?php echo e(App::isLocale('en') ? $home_section->title_en : $home_section->title_ar); ?></td>
                                <td class="text-center blue-color"><a href="<?php echo e(route('home_sections.details', $home_section->id)); ?>" ><i class="far fa-eye"></i></a></td>
                                <?php if(Auth::user()->update_data): ?> 
                                    <td class="text-center blue-color" ><a href="<?php echo e(route('home_sections.edit', $home_section->id)); ?>" ><i class="far fa-edit"></i></a></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->delete_data): ?> 
                                    <td class="text-center blue-color" ><a onclick='return confirm("<?php echo e(__('messages.are_you_sure')); ?>");' href="<?php echo e(route('home_sections.delete', $home_section->id)); ?>" ><i class="far fa-trash-alt"></i></a></td>
                                <?php endif; ?>                                
                                <?php $i++; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        
    </div>  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/ecommerce.u-smart.co/resources/views/admin/home_sections.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title' , __('messages.offers_show')); ?>

<?php $__env->startPush('scripts'); ?>
<script src="https://code.jquery.com/ui/1.10.4/jquery-ui.js" type="text/javascript"></script>

<script>
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    $("tbody#sortable").sortable({
        items : "tr",
        placeholder : "ui-state-hightlight",
        update : function () {
            var ids = $('tbody#sortable').sortable("serialize");
            var url = "<?php echo e(route('offers.sort')); ?>";
            
            $.post(url , ids + "&_token=<?php echo e(csrf_token()); ?>");
    
            //  console.log(ids);
    
    
        }
    });
</script>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div id="tableSimple" class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.offers_show') . " ( " . __('messages.drag&drop') . " )"); ?></h4>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div class="table-responsive"> 
                <table id="without-print" class="table table-hover non-hover" style="width:100%">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th><?php echo e(__('messages.image')); ?></th>
                            <th class="text-center"><?php echo e(__('messages.details')); ?></th>
                            <?php if(Auth::user()->update_data): ?> 
                                <th class="text-center"><?php echo e(__('messages.edit')); ?></th>                          
                            <?php endif; ?>
                            <?php if(Auth::user()->delete_data): ?> 
                                <th class="text-center"><?php echo e(__('messages.delete')); ?></th>                          
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody id="sortable">
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $data['offers']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr  id="id_<?php echo e($offer['id']); ?>">
                                <td><?=$i;?></td>
                                <td><img src="https://res.cloudinary.com/dagdz3cnk/image/upload/w_100,q_100/v1581928924/<?php echo e($offer->image); ?>"  /></td>
                                <td class="text-center blue-color">
                                    <a href="<?php echo e(route('offers.details', $offer->id)); ?>">
                                        <i class="far fa-eye"></i>
                                    </a>
                                </td>
                                <?php if(Auth::user()->update_data): ?> 
                                    <td class="text-center blue-color" ><a href="<?php echo e(route('offers.edit', $offer->id)); ?>" ><i class="far fa-edit"></i></a></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->delete_data): ?> 
                                    <td class="text-center blue-color" ><a onclick='return confirm("<?php echo e(__('messages.are_you_sure')); ?>");' href="<?php echo e(route('offers.delete', $offer->id)); ?>" ><i class="far fa-trash-alt"></i></a></td>
                                <?php endif; ?>                                
                                <?php $i++; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        
    </div>  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/Bshop.u-smart.co/resources/views/admin/offers.blade.php ENDPATH**/ ?>
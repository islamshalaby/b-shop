<?php $__env->startSection('title' , __('messages.category_edit')); ?>

<?php $__env->startSection('content'); ?>
    <div class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
                <div class="row">
                    <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                        <h4><?php echo e(__('messages.category_edit')); ?></h4>
                 </div>
        </div>
        <form action="" method="post" enctype="multipart/form-data" >
            <?php echo csrf_field(); ?>
            <div class="form-group mb-4">
                <label for=""><?php echo e(__('messages.current_image')); ?></label><br>
                <img src="https://res.cloudinary.com/dz3o88rdi/image/upload/w_100,q_100/v1581928924/<?php echo e($data['category']['image']); ?>"  />
            </div>
            <div class="custom-file-container" data-upload-id="myFirstImage">
                <label><?php echo e(__('messages.change_image')); ?> (<?php echo e(__('messages.single_image')); ?>) <a href="javascript:void(0)" class="custom-file-container__image-clear" title="Clear Image">x</a></label>
                <label class="custom-file-container__custom-file" >
                    <input type="file" name="image" class="custom-file-container__custom-file__custom-file-input" accept="image/*">
                    <input type="hidden" name="MAX_FILE_SIZE" value="10485760" />
                    <span class="custom-file-container__custom-file__custom-file-control"></span>
                </label>
                <div class="custom-file-container__image-preview"></div>
            </div>
            <div class="form-group mb-4">
                <label for="title_en"><?php echo e(__('messages.title_en')); ?></label>
                <input required type="text" name="title_en" class="form-control" id="title_en" placeholder="<?php echo e(__('messages.title_en')); ?>" value="<?php echo e($data['category']['title_en']); ?>" >
            </div>
            <div class="form-group mb-4">
                <label for="title_ar"><?php echo e(__('messages.title_ar')); ?></label>
                <input required type="text" name="title_ar" class="form-control" id="title_ar" placeholder="<?php echo e(__('messages.title_ar')); ?>" value="<?php echo e($data['category']['title_ar']); ?>" >
            </div>
            <input type="submit" value="<?php echo e(__('messages.submit')); ?>" class="btn btn-primary">
        </form>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/ecommerce.u-smart.co/resources/views/admin/category_edit.blade.php ENDPATH**/ ?>
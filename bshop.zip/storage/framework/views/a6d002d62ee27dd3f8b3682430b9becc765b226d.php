<?php $__env->startSection('title' , __('messages.show_products')); ?>
<?php $__env->startPush('styles'); ?>
<style>
    .filtered-list-search form button {
        left: 4px;
        right : auto
    }
    .add-prod-container {
        padding: 20px 0;
    }
    .widget.box .widget-header,
    .add-prod-container,
    .widget.prod-search {
        background-color: #1b55e2 !important;
    }
    .filtered-list-search {
        margin-top: 50px
    }
    .add-prod-container h4,
    .widget h2{
        color: #FFF
    }
    .filtered-list-search {
        margin-bottom: 0 !important
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<div id="badgeCustom" class="col-lg-12 mx-auto layout-spacing">
    <div id="card_2" class="col-lg-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div style="margin-bottom: 50px" class="widget-header">
                <div class="col-lg-8 col-md-8 col-sm-9 filtered-list-search mx-auto">
                    <form class="form-inline my-2 my-lg-0 justify-content-center">
                        <div class="w-100">
                            <input type="text" class="w-100 form-control product-search br-30" id="input-search" name="name" placeholder="<?php echo e(__('messages.search_for_product_name')); ?>">
                            <button class="btn btn-primary" type="submit"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg></button>
                        </div>
                    </form>
                </div>
                <div class="col-md-12">
                    <div class="mx-auto center-block add-prod-container text-center">
                        <h4 style="color: #FFF"><?php echo e(__('messages.you_can_add_new')); ?></h4>
                        <?php if(isset($data['sub_cat'])): ?>
                        <a href="<?php echo e(route('products.add') . '?sub_cat=' . $data['sub_cat']); ?>" class="btn btn-warning"><?php echo e(__('messages.add_new_product')); ?></a>
                        <?php else: ?>
                        <a href="<?php echo e(route('products.add')); ?>" class="btn btn-warning"><?php echo e(__('messages.add_new_product')); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php if(count($data['products']) > 0): ?>
                <?php $__currentLoopData = $data['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="widget-content widget-content-area col-md-3">
                    <div class="card component-card_2">
                        <img src="https://res.cloudinary.com/dz3o88rdi/image/upload/w_250,h_250,q_100/v1581928924/<?php echo e(isset($product->images[0]) ? $product->images[0]->image : ''); ?>" class="card-img-top" alt="widget-card-2">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e(App::isLocale('en') ? $product->title_en : $product->title_ar); ?></h5>
                            <p class="card-text"><?php echo e($product->remaining_quantity == 0 ? __('messages.out_of_stock_now') : __('messages.remaining_quantity') . " : " . $product->remaining_quantity); ?></p>
                            
                            <a href="#" data-toggle="modal" data-target="#zoomupModal<?php echo e($product->id); ?>" class="btn btn-<?php echo e($product->remaining_quantity == 0 ? 'danger' : 'primary'); ?>"><?php echo e(__('messages.add_quantity')); ?></a>
                            
                        </div>
                    </div>
                </div>
                <div id="zoomupModal<?php echo e($product->id); ?>" class="modal animated zoomInUp custo-zoomInUp" role="dialog">
                    <div class="modal-dialog">
                        <!-- Modal content-->
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title"><?php echo e(App::isLocale('en') ? $product->title_en : $product->title_ar); ?></h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <svg aria-hidden="true" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-x"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
                                </button>
                            </div>
                            <div class="modal-body">
                                <form action="<?php echo e(route('update.quantity', $product->id)); ?>" method="post" enctype="multipart/form-data" >
                                    <?php echo csrf_field(); ?>    
                                    <div class="form-group mb-4">
                                        <label for="remaining_quantity"><?php echo e(__('messages.quantity')); ?></label>
                                        <input required type="text" name="remaining_quantity" class="form-control" id="remaining_quantity" placeholder="<?php echo e(__('messages.quantity')); ?>" value="" >
                                    </div>
                        
                                    <input type="submit" value="<?php echo e(__('messages.add')); ?>" class="btn btn-primary">
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <div class="col-md-12">
                    <div class="mx-auto center-block text-center">
                        <h5 class="text-center center-block"><?php echo e(__('messages.no_result')); ?> 
                            <?php if(isset($data['sub_cat'])): ?>
                            <a href="<?php echo e(route('products.add') . '?sub_cat=' . $data['sub_cat']); ?>"><?php echo e(__('messages.click_here')); ?></a>
                            <?php else: ?>
                            <a href="<?php echo e(route('products.add')); ?>"><?php echo e(__('messages.click_here')); ?></a>
                            <?php endif; ?>
                             <?php echo e(__('messages.to_add_new_product')); ?></h5>
                    </div>
                </div>
                <?php endif; ?>

                <div style="margin-top: 50px" class="col-md-12">
                    <div class="mx-auto center-block add-prod-container text-center">
                        <h4><?php echo e(__('messages.you_can_add_new')); ?></h4>
                        <?php if(isset($data['sub_cat'])): ?>
                        <a href="<?php echo e(route('products.add') . '?sub_cat=' . $data['sub_cat']); ?>" class="btn btn-warning"><?php echo e(__('messages.add_new_product')); ?></a>
                        <?php else: ?>
                        <a href="<?php echo e(route('products.add')); ?>" class="btn btn-warning"><?php echo e(__('messages.add_new_product')); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
</div>  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/ecommerce.u-smart.co/resources/views/admin/searched_products.blade.php ENDPATH**/ ?>
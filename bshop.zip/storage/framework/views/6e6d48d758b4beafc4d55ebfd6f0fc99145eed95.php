<?php $__env->startSection('title' , __('messages.show_options')); ?>

<?php $__env->startSection('content'); ?>
    <div id="tableSimple" class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.show_options')); ?></h4>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div class="table-responsive"> 
                <table id="without-print" class="table table-hover non-hover" style="width:100%">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th><?php echo e(__('messages.option_title')); ?></th>
                            <th><?php echo e(__('messages.category')); ?></th>
                            <?php if(Auth::user()->update_data): ?> 
                                <th class="text-center"><?php echo e(__('messages.edit')); ?></th>                          
                            <?php endif; ?>
                            <?php if(Auth::user()->delete_data): ?> 
                                <th class="text-center"><?php echo e(__('messages.delete')); ?></th>                          
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $data['options']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?=$i;?></td>
                                <td><?php echo e(App::isLocale('en') ? $option->title_en : $option->title_ar); ?></td>
                                <td>
                                    <a href="<?php echo e(route('categories.details', $option->category->id)); ?>">
                                    <?php echo e(App::isLocale('en') ? $option->category->title_en : $option->category->title_ar); ?>

                                    </a>
                                </td>
                                <?php if(Auth::user()->update_data): ?> 
                                <td class="text-center blue-color" ><a href="<?php echo e(route('options.edit', $option->id)); ?>" ><i class="far fa-edit"></i></a></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->delete_data): ?> 
                                    <td class="text-center blue-color" ><a onclick='return confirm("<?php echo e(__('messages.are_you_sure')); ?>");' href="<?php echo e(route('options.delete', $option->id)); ?>" ><i class="far fa-trash-alt"></i></a></td>
                                <?php endif; ?>  
                                <?php $i++; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/ecommerce.u-smart.co/resources/views/admin/options.blade.php ENDPATH**/ ?>
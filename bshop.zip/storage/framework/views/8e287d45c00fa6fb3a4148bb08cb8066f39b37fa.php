<?php $__env->startSection('title' , __('messages.statistics')); ?>
<?php $__env->startPush('styles'); ?>
<?php if(App::isLocale('ar')): ?>
<link href="/admin/rtl/assets/css/apps/invoice.css" rel="stylesheet" type="text/css" />
<?php else: ?>
<link href="/admin/assets/css/apps/invoice.css" rel="stylesheet" type="text/css" />
<?php endif; ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="layout-px-spacing">
    <div class="row invoice layout-top-spacing">
        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
            <div class="app-hamburger-container">
                <div class="hamburger"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-menu chat-menu d-xl-none"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg></div>
            </div>
            <div class="doc-container">


                <div class="tab-title">
                    <div class="row">
                        <div class="col-md-12 col-sm-12 col-12">
                            <div class="search">
                                <input type="text" class="form-control" placeholder="Search...">
                            </div>
                            <ul class="nav nav-pills inv-list-container d-block" id="pills-tab" role="tablist">
                                <li class="nav-item">
                                    <div class="nav-link list-actions" id="invoice-00001" data-invoice-id="00001">
                                        <div class="f-m-body">
                                            <div class="f-head">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-activity"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                                            </div>
                                            <div class="f-body">
                                                <p class="invoice-number"><?php echo e(__('messages.statistics')); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </li>

                                <li class="nav-item">
                                    <div class="nav-link list-actions" id="invoice-00002" data-invoice-id="00002">
                                        <div class="f-m-body">
                                            <div class="f-head">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-activity"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                                            </div>
                                            <div class="f-body">
                                                <p class="invoice-number"><?php echo e(__('messages.today_stats')); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </li>

                                <li class="nav-item">
                                    <div class="nav-link list-actions" id="invoice-00003" data-invoice-id="00003">
                                        <div class="f-m-body">
                                            <div class="f-head">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-activity"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                                            </div>
                                            <div class="f-body">
                                                <p class="invoice-number"><?php echo e(__('messages.most_sold_product')); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </li>

                                <li class="nav-item">
                                    <div class="nav-link list-actions" id="invoice-00004" data-invoice-id="00004">
                                        <div class="f-m-body">
                                            <div class="f-head">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-activity"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                                            </div>
                                            <div class="f-body">
                                                <p class="invoice-number"><?php echo e(__('messages.most_area_order')); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </li>

                                <li class="nav-item">
                                    <div class="nav-link list-actions" id="invoice-00005" data-invoice-id="00005">
                                        <div class="f-m-body">
                                            <div class="f-head">
                                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-activity"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                                            </div>
                                            <div class="f-body">
                                                <p class="invoice-number"><?php echo e(__('messages.most_user_order')); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                </li>

                            </ul>
                        </div>
                    </div>
                </div>



                <div class="invoice-container">
                    <div class="invoice-inbox">

                        <div class="inv-not-selected">
                            <p><?php echo e(__('messages.Open_statistic_from_the_list')); ?></p>
                        </div>

                        <div class="invoice-header-section">
                            
                            <div class="invoice-action">
                                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-printer action-print" data-toggle="tooltip" data-placement="top" data-original-title="Reply"><polyline points="6 9 6 2 18 2 18 9"></polyline><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"></path><rect x="6" y="14" width="12" height="8"></rect></svg>
                            </div>
                        </div>
                        
                        <div id="ct" class="">
                            
                            <div class="invoice-00001">
                                <div class="content-section  animated animatedFadeInUp fadeInUp">

                                    <div class="row inv--head-section">

                                        <div class="col-sm-6 col-12">
                                            <h3 class="in-heading"><?php echo e(__('messages.statistics')); ?></h3>
                                        </div>
                                        
                                        
                                    </div>

                                    <div class="row inv--detail-section">
                                        <div class="col-12">
                                            <div class="col-12">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead class="">
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.users_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['users']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.ads_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['ads']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.categories_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['categories']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.contact_us_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['contact_us']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.brands_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['brands']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.sub_categories_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['sub_categories']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.products_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['products']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.offers_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['offers']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.areas_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['areas']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.orders_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['orders']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.orders_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['orders']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.in_progress_orders_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['in_progress_orders']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.canceled_orders_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['canceled_orders']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.delivered_orders_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['delivered_orders']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.delivered_orders_cost')); ?></th>
                                                                <th scope="col"><?php echo e($data['delivered_orders_cost']); ?> <?php echo e(__('messages.dinar')); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.canceled_orders_cost')); ?></th>
                                                                <th scope="col"><?php echo e($data['canceled_orders_cost']); ?> <?php echo e(__('messages.dinar')); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.in_progress_orders_cost')); ?></th>
                                                                <th scope="col"><?php echo e($data['in_progress_orders_cost']); ?> <?php echo e(__('messages.dinar')); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.total_orders_cost')); ?></th>
                                                                <th scope="col"><?php echo e($data['total_orders_cost']); ?> <?php echo e(__('messages.dinar')); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.cash_orders_cost')); ?></th>
                                                                <th scope="col"><?php echo e($data['cash_orders_cost']); ?> <?php echo e(__('messages.dinar')); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.key_net_orders_cost')); ?></th>
                                                                <th scope="col"><?php echo e($data['key_net_orders_cost']); ?> <?php echo e(__('messages.dinar')); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.key_net_home_orders_cost')); ?></th>
                                                                <th scope="col"><?php echo e($data['key_net_home_orders_cost']); ?> <?php echo e(__('messages.dinar')); ?></th>
                                                            </tr>
                                                        </thead>
                                                        
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div> 

                            <div class="invoice-00002">
                                <div class="content-section  animated animatedFadeInUp fadeInUp">

                                    <div class="row inv--head-section">

                                        <div class="col-sm-6 col-12">
                                            <h3 class="in-heading"><?php echo e(__('messages.today_stats')); ?></h3>
                                        </div>
                                        
                                        
                                    </div>

                                    <div class="row inv--detail-section">
                                        <div class="col-12">
                                            <div class="col-12">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead class="">
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.users_today_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['users_today_count']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.contact_us_today_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['contact_us_today_count']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.products_today_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['products_today_count']); ?></th>
                                                            </tr>
                                                            
                                                            
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.today_orders_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['today_orders']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.in_progress_orders_today_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['in_progress_orders_today_count']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.canceled_orders_today_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['canceled_orders_today_count']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.delivered_orders_today_count')); ?></th>
                                                                <th scope="col"><?php echo e($data['delivered_orders_today_count']); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.today_delivered_orders_cost')); ?></th>
                                                                <th scope="col"><?php echo e($data['today_delivered_orders_cost']); ?> <?php echo e(__('messages.dinar')); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.today_canceled_orders_cost')); ?></th>
                                                                <th scope="col"><?php echo e($data['today_canceled_orders_cost']); ?> <?php echo e(__('messages.dinar')); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.today_in_progress_orders_cost')); ?></th>
                                                                <th scope="col"><?php echo e($data['today_in_progress_orders_cost']); ?> <?php echo e(__('messages.dinar')); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.today_cash_cost')); ?></th>
                                                                <th scope="col"><?php echo e($data['today_cash_cost']); ?> <?php echo e(__('messages.dinar')); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.today_key_net_cost')); ?></th>
                                                                <th scope="col"><?php echo e($data['today_key_net_cost']); ?> <?php echo e(__('messages.dinar')); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.today_key_net_home_cost')); ?></th>
                                                                <th scope="col"><?php echo e($data['today_key_net_home_cost']); ?> <?php echo e(__('messages.dinar')); ?></th>
                                                            </tr>
                                                            
                                                        </thead>
                                                        
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="invoice-00003">
                                <div class="content-section  animated animatedFadeInUp fadeInUp">

                                    <div class="row inv--head-section">

                                        <div class="col-sm-6 col-12">
                                            <h3 class="in-heading"><?php echo e(__('messages.most_sold_product')); ?></h3>
                                        </div>
                                        
                                        
                                    </div>

                                    <div class="row inv--detail-section">
                                        <div class="col-12">
                                            <?php $__currentLoopData = $data['most_sold_products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-12">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead class="">
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.title_en')); ?></th>
                                                                <th scope="col"><a target="_blank" href="<?php echo e(route('products.details', $prod)); ?>"><?php echo e($prod->title_en); ?></a> </th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.title_ar')); ?></th>
                                                                <th scope="col"><?php echo e($prod->title_ar); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.count')); ?></th>
                                                                <th scope="col"><?php echo e($prod->cnt); ?></th>
                                                            </tr>
                                                            
                                                        </thead>
                                                        
                                                    </table>
                                                    
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="invoice-00004">
                                <div class="content-section  animated animatedFadeInUp fadeInUp">

                                    <div class="row inv--head-section">

                                        <div class="col-sm-6 col-12">
                                            <h3 class="in-heading"><?php echo e(__('messages.most_area_order')); ?></h3>
                                        </div>
                                        
                                        
                                    </div>

                                    <div class="row inv--detail-section">
                                        <div class="col-12">
                                            <?php $__currentLoopData = $data['most_areas_order']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-12">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead class="">
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.title_en')); ?></th>
                                                                <th scope="col"><a target="_blank" href="<?php echo e(route('areas.details', $area)); ?>"><?php echo e($area->title_en); ?></a> </th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.title_ar')); ?></th>
                                                                <th scope="col"><?php echo e($area->title_ar); ?></th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.orders_number')); ?></th>
                                                                <th scope="col"><?php echo e($area->cnt); ?></th>
                                                            </tr>
                                                            
                                                        </thead>
                                                        
                                                    </table>
                                                    
                                                </div>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            
                                        </div>
                                    </div>

                                </div>
                            </div>

                            <div class="invoice-00005">
                                <div class="content-section  animated animatedFadeInUp fadeInUp">

                                    <div class="row inv--head-section">

                                        <div class="col-sm-6 col-12">
                                            <h3 class="in-heading"><?php echo e(__('messages.most_user_order')); ?></h3>
                                        </div>
                                        
                                        
                                    </div>

                                    <div class="row inv--detail-section">
                                        <?php $__currentLoopData = $data['most_users_order']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-12">
                                            <div class="col-12">
                                                <div class="table-responsive">
                                                    <table class="table">
                                                        <thead class="">
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.user_name')); ?></th>
                                                                <th scope="col"><a target="_blank" href="<?php echo e(route('users.details', $user)); ?>"><?php echo e($user->name); ?></a> </th>
                                                            </tr>
                                                            <tr>
                                                                <th scope="col"><?php echo e(__('messages.orders_number')); ?></th>
                                                                <th scope="col"><?php echo e($user->cnt); ?></th>
                                                            </tr>
                                                            
                                                        </thead>
                                                        
                                                    </table>
                                                    
                                                </div>
                                            </div>
                                            
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>

                                </div>
                            </div>

                        </div>


                    </div>

                    <div class="inv--thankYou">
                        <div class="row">
                            <div class="col-sm-12 col-12">
                                <p class="">Thank you for doing Business with us.</p>
                            </div>
                        </div>
                    </div>

                </div>
                
            </div>

        </div>
    </div>
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/ecommerce.u-smart.co/resources/views/admin/stats.blade.php ENDPATH**/ ?>
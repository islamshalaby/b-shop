<?php $__env->startSection('title' , __('messages.show_brands')); ?>

<?php $__env->startSection('content'); ?>
    <div id="tableSimple" class="col-lg-12 col-12 layout-spacing">
        <div class="statbox widget box box-shadow">
            <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.show_brands')); ?></h4>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div class="table-responsive"> 
                <table id="without-print" class="table table-hover non-hover" style="width:100%">
                    <thead>
                        <tr>
                            <th>Id</th>
                            <th><?php echo e(__('messages.brand_title')); ?></th>
                            <th class="text-center"><?php echo e(__('messages.details')); ?></th>
                            <?php if(Auth::user()->update_data): ?> 
                                <th class="text-center"><?php echo e(__('messages.edit')); ?></th>                          
                            <?php endif; ?>
                            <?php if(Auth::user()->delete_data): ?> 
                                <th class="text-center"><?php echo e(__('messages.delete')); ?></th>                          
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $data['brands']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?=$i;?></td>
                                <td><?php echo e(App::isLocale('en') ? $brand->title_en : $brand->title_ar); ?></td>
                                <td class="text-center blue-color"><a href="<?php echo e(route('brands.details', $brand->id)); ?>" ><i class="far fa-eye"></i></a></td>
                                <?php if(Auth::user()->update_data): ?> 
                                    <td class="text-center blue-color" ><a href="<?php echo e(route('brands.edit', $brand->id)); ?>" ><i class="far fa-edit"></i></a></td>
                                <?php endif; ?>
                                <?php if(Auth::user()->delete_data): ?> 
                                    <td class="text-center blue-color" >
                                        <?php if(count($brand->products) == 0): ?>
                                        <a onclick='return confirm("<?php echo e(__('messages.are_you_sure')); ?>");' href="<?php echo e(route('brands.delete', $brand->id)); ?>" ><i class="far fa-trash-alt"></i></a>
                                        <?php else: ?>
                                        <?php echo e(__('messages.category_has_products')); ?>

                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>                                
                                <?php $i++; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        
    </div>  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/ecommerce.u-smart.co/resources/views/admin/brands.blade.php ENDPATH**/ ?>
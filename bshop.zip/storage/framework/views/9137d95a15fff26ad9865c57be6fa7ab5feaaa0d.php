<?php
    $title = __('messages.show_orders');
    if (!empty($data['from'])) {
        $title = __('messages.show_orders') . " ( " . __('messages.from') . ": " . $data['from'] . " " . __('messages.to') . ": " . $data['to'] . " )";
    }else if (isset($data['area'])) {
        if (App::isLocale('en')) {
            $title = __('messages.show_orders') . " ( " . $data['area']['title_en'] . " )";
        }else {
            $title = __('messages.show_orders') . " ( " . $data['area']['title_ar'] . " )";
        }
        
    }else if(isset($data['method'])) {
        if($data['method'] == 1) {
            $title = __('messages.show_orders') . " ( " . __('messages.key_net') . " )";
        }elseif ($data['method'] == 2) {
            $title = __('messages.show_orders') . " ( " . __('messages.key_net_from_home') . " )";
        }else {
            $title = __('messages.show_orders') . " ( " . __('messages.cash') . " )";
        }
    }
?>

<?php $__env->startSection('title' , $title ); ?>
<?php
$url = 'http://' . $_SERVER['SERVER_NAME'] . $_SERVER['REQUEST_URI'];
?>

<?php $__env->startPush('scripts'); ?>
    <script>
        var language = "<?php echo e(Config::get('app.locale')); ?>"
        $("#area_select").on("change", function() {
            $("#areaForm").submit()
        })
        $("#toDate").on("change", function() {
            console.log("test")
            $("#dateForm").submit()
        })
        $("#payment_select").on("change", function() {
            $("#paymentForm").submit()
        })
    </script>
    
    

    <script>
        var ttle = "<?php echo e($title); ?>",
            sumPrice = "<?php echo e($data['sum_price']); ?>",
            priceString = "<?php echo e(__('messages.price')); ?>",
            deliveryString = "<?php echo e(__('messages.delivery_cost')); ?>",
            sumDelivery = "<?php echo e($data['sum_delivery']); ?>",
            sumTotal = "<?php echo e($data['sum_total']); ?>",
            totalString = "<?php echo e(__('messages.total_with_delivery')); ?>",
            dinar = "<?php echo e(__('messages.dinar')); ?>"
        var dTbls = $('#order-tbl').DataTable( {
            dom: 'Blfrtip',
            buttons: {
                buttons: [
                    { extend: 'copy', className: 'btn', footer: true, exportOptions: {
                        columns: ':visible',
                        rows: ':visible'
                    }},
                    { extend: 'csv', className: 'btn', footer: true, exportOptions: {
                        columns: ':visible',
                        rows: ':visible'
                    } },
                    { extend: 'excel', className: 'btn', footer: true, exportOptions: {
                        columns: ':visible',
                        rows: ':visible'
                    } },
                    { extend: 'print', className: 'btn', footer: true, 
                        exportOptions: {
                            columns: ':visible',
                            rows: ':visible'
                        },customize: function(win) {
                            $(win.document.body).prepend(`<br /><h4 style="border-bottom: 1px solid; padding : 10px">${priceString} : ${sumPrice} ${dinar} | ${deliveryString} : ${sumDelivery} ${dinar} | ${totalString} : ${sumTotal} ${dinar}</h4>`); //before the table
                          }
                    }
                ]
            },
            "oLanguage": {
                "oPaginate": { "sPrevious": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-left"><line x1="19" y1="12" x2="5" y2="12"></line><polyline points="12 19 5 12 12 5"></polyline></svg>', "sNext": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-arrow-right"><line x1="5" y1="12" x2="19" y2="12"></line><polyline points="12 5 19 12 12 19"></polyline></svg>' },
                "sInfo": "Showing page _PAGE_ of _PAGES_",
                "sSearch": '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-search"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>',
                "sSearchPlaceholder": "Search...",
               "sLengthMenu": "Results :  _MENU_",
            },
            "stripeClasses": [],
            "lengthMenu": [50, 100, 1000, 10000, 100000, 1000000, 2000000, 3000000, 4000000, 5000000],
            "pageLength": 50  
        } );
    </script>
    <script>
        var price = dTbls.column(6).data(),
            delivery = dTbls.column(7).data(),
            total = dTbls.column(8).data(),
            dinar = "<?php echo e(__('messages.dinar')); ?>"
        var totalPrice = parseFloat(price.reduce(function (a, b) { return parseFloat(a) + parseFloat(b); }, 0)).toFixed(2),
            totalDelivery = parseFloat(delivery.reduce(function (a, b) { return parseFloat(a) + parseFloat(b); }, 0)).toFixed(2),
            allTotal = parseFloat(total.reduce(function (a, b) { return parseFloat(a) + parseFloat(b); }, 0)).toFixed(2)

        $("#order-tbl tfoot").find('th').eq(6).text(`${totalPrice} ${dinar}`);
        $("#order-tbl tfoot").find('th').eq(7).text(`${totalDelivery} ${dinar}`);
        $("#order-tbl tfoot").find('th').eq(8).text(`${allTotal} ${dinar}`);
    </script>
    
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div id="tableSimple" class="col-lg-12 col-12 layout-spacing"> 
        <div class="statbox widget box box-shadow">
            <div class="col-lg-12 filtered-list-search mx-auto">
                <div class="btn-group" role="group" aria-label="Basic example">
                    <a href="<?php echo e(route('orders.index')); ?>" type="button" class="btn btn-<?php echo e(strpos($url,'show') !== false || strpos($url,'fetchbydate') !== false ? 'light' : 'dark'); ?>"><?php echo e(__('messages.all_orders')); ?></a>
                    <a href="<?php echo e(route('orders.filter', 1)); ?>" type="button" class="btn btn-<?php echo e(request()->segment(count(request()->segments())) == 1 ? 'light' : 'dark'); ?>"><?php echo e(__('messages.in_progress_orders')); ?></a>
                    <a href="<?php echo e(route('orders.filter', 3)); ?>" type="button" class="btn btn-<?php echo e(request()->segment(count(request()->segments())) == 3 ? 'light' : 'dark'); ?>"><?php echo e(__('messages.canceled_orders')); ?></a>
                    <a href="<?php echo e(route('orders.filter', 2)); ?>" type="button" class="btn btn-<?php echo e(request()->segment(count(request()->segments())) == 2 ? 'light' : 'dark'); ?>"><?php echo e(__('messages.delivered_orders')); ?></a>
                </div>
            </div>
            <div class="widget-content widget-content-area">
                <div class="row">
                    <div class="form-group col-md-3">
                        <form id="areaForm" method="" action="<?php echo e(strpos($url,'filter') !== false ? '' : route('orders.fetchbyarea')); ?>">
                            
                            <label for="area"><?php echo e(__('messages.area')); ?></label>
                            <select required id="area_select" name="area_id" class="form-control">
                                <option disabled selected><?php echo e(__('messages.select')); ?></option>
                                <?php $__currentLoopData = $data['areas']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php echo e(isset($data['area']) && $data['area']['id'] == $area->id ? 'selected' : ''); ?> value="<?php echo e($area->id); ?>"><?php echo e(App::isLocale('en') ? $area->title_en : $area->title_ar); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                            </select>
                                
                        </form>
                    </div>
                    <div class="form-group col-md-6">
                        <form id="dateForm" method="" action="<?php echo e(strpos($url,'filter') !== false ? '' : route('orders.fetchbydate')); ?>">
                            <div class="form-group mb-4">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label for="from"><?php echo e(__('messages.from')); ?></label>
                                        <input required type="date" name="from" class="form-control" id="from" >
                                    </div>
                                    <div class="col-md-6">
                                        <label for="toDate"><?php echo e(__('messages.to')); ?></label>
                                        <input required type="date" name="to" class="form-control" id="toDate" >
                                    </div>
                                </div>
                            </div>
                            
                        </form>
                    </div>

                    <div class="form-group col-md-3">
                        <form id="paymentForm" method="" action="<?php echo e(strpos($url,'filter') !== false ? '' : route('orders.fetchbypayment')); ?>">
                            
                            <label for="payment_select"><?php echo e(__('messages.payment_method')); ?></label>
                            <select required id="payment_select" name="method" class="form-control">
                                <option disabled selected><?php echo e(__('messages.select')); ?></option>
                                
                                <option <?php echo e(isset($data['method']) && $data['method'] == 1 ? 'selected' : ''); ?> value="1"><?php echo e(__('messages.key_net')); ?></option>
                                <option <?php echo e(isset($data['method']) && $data['method'] == 2 ? 'selected' : ''); ?> value="2"><?php echo e(__('messages.key_net_from_home')); ?></option>
                                <option <?php echo e(isset($data['method']) && $data['method'] == 3 ? 'selected' : ''); ?> value="3"><?php echo e(__('messages.cash')); ?></option>
                                
                            </select>
                                
                        </form>
                    </div>
                </div>
                
        
            </div>
            
            <div class="widget-header">
            <div class="row">
                <div class="col-xl-12 col-md-12 col-sm-12 col-12">
                    <h4><?php echo e(__('messages.show_orders')); ?> 
                        <?php if(isset($data['area'])): ?>
                            <?php if(App::isLocale('en')): ?>
                                <?php echo e("( " . $data['area']['title_en'] . " )"); ?>

                            <?php else: ?>
                                <?php echo e("( " . $data['area']['title_ar'] . " )"); ?>

                            <?php endif; ?>
                        <?php endif; ?>
                        <button data-show="0" class="btn btn-primary show_actions"><?php echo e(__('messages.hide_actions')); ?></button>
                    </h4>
                </div>
            </div>
        </div>
        <div class="widget-content widget-content-area">
            <div class="table-responsive"> 
                <table id="order-tbl" class="table table-hover non-hover" style="width:100%">
                    <thead>
                        <tr>
                            <th>id</th>
                            <th><?php echo e(__('messages.order_number')); ?></th>
                            <th><?php echo e(__('messages.order_date')); ?></th>
                            <th><?php echo e(__('messages.user')); ?></th>
                            <th><?php echo e(__('messages.payment_method')); ?></th>
                            <th><?php echo e(__('messages.status')); ?></th>
                            <th><?php echo e(__('messages.price')); ?></th>
                            <th><?php echo e(__('messages.delivery_cost')); ?></th>
                            <th><?php echo e(__('messages.total_with_delivery')); ?></th>
                            <th class="hide_col text-center"><?php echo e(__('messages.actions')); ?></th>
                            <th class="text-center hide_col"><?php echo e(__('messages.details')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                       
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $data['orders']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?=$i;?></td>
                                <td><?php echo e($order->order_number); ?></td>
                                <td><?php echo e($order->created_at->format("d-m-y")); ?></td>
                                <td>
                                    <a target="_blank" href="<?php echo e(route('users.details', $order->user->id)); ?>">
                                    <?php echo e($order->user->name); ?>

                                    </a>
                                </td>
                                <td>
                                    <?php if($order->payment_method == 1): ?>
                                    <?php echo e(__('messages.key_net')); ?>

                                    <?php elseif($order->payment_method == 2): ?>
                                    <?php echo e(__('messages.key_net_from_home')); ?>

                                    <?php else: ?>
                                    <?php echo e(__('messages.cash')); ?>

                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($order->status == 1): ?>
                                    <?php echo e(__('messages.in_progress')); ?>

                                    <?php elseif($order->status == 2): ?>
                                    <?php echo e(__('messages.delivered')); ?>

                                    <?php else: ?>
                                    <?php echo e(__('messages.canceled')); ?>

                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($order->subtotal_price . " " . __('messages.dinar')); ?></td>
                                <td><?php echo e($order->delivery_cost . " " . __('messages.dinar')); ?></td>
                                <td><?php echo e($order->total_price . " " . __('messages.dinar')); ?></td>
                                <td class="hide_col text-center">
                                    <?php if($order->status == 1): ?>
                                    <a style="margin-bottom: 5px" href="<?php echo e(route('orders.action', [$order->id, 3])); ?>" onclick='return confirm("<?php echo e(__('messages.are_you_sure')); ?>");' class="btn btn-sm btn-danger hide_col">
                                        <?php echo e(__('messages.cancel_order')); ?>

                                    </a>
                                    <a href="<?php echo e(route('orders.action', [$order->id, 2])); ?>" onclick='return confirm("<?php echo e(__('messages.are_you_sure')); ?>");' class="btn btn-sm btn-success hide_col">
                                        <?php echo e(__('messages.order_delivered')); ?>

                                    </a>
                                    <?php endif; ?>
                                    <?php if($order->status == 2): ?>
                                    <a style="margin-bottom: 5px" href="<?php echo e(route('orders.action', [$order->id, 3])); ?>" onclick='return confirm("<?php echo e(__('messages.are_you_sure')); ?>");' class="btn btn-sm btn-danger hide_col">
                                        <?php echo e(__('messages.cancel_order')); ?>

                                    </a>
                        
                                    <?php endif; ?>

                                    
                                </td>
                                <td class="text-center blue-color hide_col"><a href="<?php echo e(route('orders.invoice', $order->id)); ?>" ><i class="far fa-eye"></i></a></td>
                            </tr>
                            <?php $i ++ ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot>
                        <tr>
                          <th><?php echo e(__('messages.total')); ?>:</th>
                          <th></th>
                          <th></th>
                          <th></th>
                          <th></th>
                          <th></th>
                          <th></th>
                          <th></th>
                          <th></th>
                        </tr>
                    </tfoot>
                </table>
            </div>
        </div>

    </div>  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/vhosts/u-smart.co/Bshop.u-smart.co/resources/views/admin/orders.blade.php ENDPATH**/ ?>